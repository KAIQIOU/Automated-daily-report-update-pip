# daily-digest-pipeline SKILL · v1.5

> **目标**: 让任何 agent 拿到这个 self-contained skill, 从零跑出"数据分析 + AI 应用方向"的**每日中文日报** — RSS 抓取 + markitdown + LLM 总结 + 单文件 HTML 渲染 + 飞书 DM 发送 + Bitable 同步 — 视觉与产物严格一致。

**适用对象**: vibecoder / 数据分析 + AI 应用小组, 需要每 24h 一次的高质量信源摘要。
**核心特征**: 9 源 + 3 主题 + LLM 总结 + 4 tab 切换单文件 HTML + 飞书 DM 附件 + Bitable 多维表格同步 + 双 verify 10:40 兜底。
**版本**: v1.5 (2026-07-03, 从 v1.2 跨代升级 5 项 + 加 7 运营脚本)

---

## 📑 目录 (TOC)

1. [产出一览](#1-产出一览)
2. [用户偏好 (硬约束)](#2-用户偏好-硬约束)
3. [信源池 (9 个)](#3-信源池-9-个)
4. [5 步 Pipeline](#4-5-步-pipeline)
5. [产物命名 (V1.x + 科技日报 V 号)](#5-产物命名)
6. [HTML 设计规范](#6-html-设计规范)
7. [核心脚本清单 + 调用方法](#7-核心脚本清单)
8. [运营脚本清单 (飞书 + Bitable)](#8-运营脚本清单)
9. [常见坑 + workaround (v1.5 增 8 条)](#9-常见坑--workaround)
10. [验收 checklist](#10-验收-checklist)
11. [3 段时间窗 (9:50 / 10:10 / 10:40)](#11-3-段时间窗)

---

## 1. 产出一览

```
./daily-reports\
└── 科技日报V1.0-2026-7-3\              ← 新命名规范 6-22 起
    ├── 科技日报V1.0-2026-7-3.html       ← 主产物: 单文件 HTML (≈52 KB)
    ├── 科技日报V1.0-2026-7-3.json       ← LLM 总结 (12 条)
    └── 科技日报V1.0-2026-7-3 md.材料\   ← 12+ 篇 markitdown 原文 + manifest.json
        ├── 01-xxx.md
        ├── 02-xxx.md
        ├── ...
        └── manifest.json                ← 动态主题映射 (markitdown_automate.py 生成)
```

| 产物 | 大小 | 说明 |
|---|---|---|
| `科技日报VN.N-YYYY-M-D.html` | 50-55 KB | 单文件, 离线可开, 含 tab 切换 + 3 主题 + 12 条 (每主题 TOP 4) |
| `科技日报VN.N-YYYY-M-D.json` | 16 KB | 12 条 LLM 输出 (summary/value/key_points/star/why_read/pub_date) |
| `科技日报VN.N-YYYY-M-D md.材料/*.md` | 320 KB | markitdown 后的原文, 供 LLM 重跑 / 验证 |
| `manifest.json` | 5 KB | 动态主题映射 (theme/src_name/url) — 加新源不用改 THEME_MAP |

**下游 (运营层)**:
- 飞书 DM (收件人) 收到 HTML file 附件 (附件名规范化为"科技日报 YYYY-MM-DD.html")
- 飞书 Bitable "科技日报-每日更新" 表格多一行, 含规范命名 + 附件

---

## 2. 用户偏好 (硬约束)

> ⚠️ **优先级最高, 任何 agent 不得违反**

### 🚫 不允许做的事
- ❌ **不静默覆盖** 旧版日报 (必须用 V1.0 → V1.1 → V1.2 命名)
- ❌ **不删除** 之前版本觉得"不错"的功能 (星级/留言/发布日期/为什么读)
- ❌ **不要 emoji 当 icon** (改用线性 SVG)
- ❌ **不破坏** 莫兰迪色板 (粉/橙黄/绿 8 色)
- ❌ **不要** anchor 滚动 tab (要用纯 CSS radio 切换)
- ❌ **不要** 让 Bitable 用磁盘原始命名 (V 号 / daily-V1.1), 一律规范化"科技日报 YYYY-MM-DD"

### ✅ 必须保留的"v0.3 不错功能"
| 字段 | 来源 | 显示位置 |
|---|---|---|
| **star** (1-5 ★) | LLM 评分 | item 标题旁的 star-row |
| **why_read** (≤40字) | LLM 写 | item 内独立"为什么读"区块 (斜体底色) |
| **pub_date** (YYYY-MM-DD) | LLM 推断 + md 头/URL 兜底 | item meta 旁 📅 小标签 |

### ✅ 必须遵循的"v1.1 视觉约定"
- **4 tab 切换**: 总览 / 动手 / 提升 / 视野, sticky 顶栏, 纯 CSS radio 实现
- **总览 panel**: 3 列 grid 概览卡, 每张 = 色块+主题名+条数+brief+前3条标题
- **主题 panel**: 4 条 item, 每条 = 序号+star+标题+src+pub_date+4 区块 (按 star desc → pub_date desc 排序)
- **末尾溯源链接**: 用户**只读总结**, 链接是供核验真实性

---

## 3. 信源池 (9 个)

完整 `config/sources.example.json` 已附 9 个源, 维护规则:

| 源 | 区域 | parser | 数量 | 备注 |
|---|---|---|---|---|
| Simon Willison's Weblog | en | default_rss | 6 | ★★★★★ 必读, 日更 |
| Latent Space | en | default_rss | 2 | ★★★★★ AI Eng 播客, 周更 |
| Hacker News (front page) | en | default_rss | 10 | ★★★★☆ 全员信号 |
| GitHub Trending · Python (daily) | en | github_trending | 10 | ★★★★☆ 新 agent 早现 |
| r/AI_Agents | en | default_rss | 8 | ★★★★☆ 多 agent 集中地 |
| 量子位 QbitAI | zh | default_rss | 8 | ★★★★★ 国内 AI 头牌 |
| 36 氪 | zh | default_rss | 8 | ★★★★☆ 创投视角 |
| 掘金 (热门) | zh | default_rss | 8 | ★★★★☆ 开发者 UGC |
| V2EX · tech | zh | default_rss | 10 | ★★★☆☆ 边角 |

**信源池维护** (见 [[source-screening-method]]):
- 4 维评分: 频率 / 信噪比 / 调性 / 价值
- 池子 5-7 个封顶
- 砍掉连续 2 周 < 0.6 的源; 加入新源需跑 1 周观察期

---

## 4. 5 步 Pipeline (v1.5 全自动, 跑 1 个命令)

```
[1]   抓 RSS          → digests/{date}-daily.md               (~30s)
[1.5] 跨日去重        → 滤掉 state.pushed 14 天内的重复        (~0s, 自动)
[2]   markitdown      → digests/{date} md.材料/*.md + manifest.json (~3min)
[3]   LLM 总结        → digests/{date}-summaries.json          (~3min, 12 次 LLM call)
[4]   渲染 HTML       → digests/{date}-daily-v04.html          (~1s)
[5]   publish 团队目录 → 半自动日报更新/科技日报V1.0-2026-7-3/   (cp + 新命名规范)
```

### 一键跑 (v1.5 新增)

```bash
cd scripts/
python run_daily.py 2026-07-03
# 等价于 5 个步骤全跑 + publish 团队目录
```

或用 bat 一键 (Windows):
```cmd
cd scripts
run_daily.bat
```

**跑通后产出**:
```
./daily-reports\科技日报V1.0-2026-7-3\
├── 科技日报V1.0-2026-7-3.html
├── 科技日报V1.0-2026-7-3.json
└── 科技日报V1.0-2026-7-3 md.材料\
    ├── 01-xxx.md
    ├── manifest.json
    └── ...
```

### Step 1: 抓 RSS

```bash
cd scripts/
python agent.py
# 写 digests/{date}-daily.md
```

**关键点**:
- **禁系统代理 patch (v1.4 新增, 必带)**: `urllib.request.getproxies = lambda: {}` + `requests.sessions.Session.trust_env = False`
  - **Why**: Windows 系统代理 127.0.0.1:7890 (clash 挂) → RSS + LLM 全失败
- 配置文件: `config/sources.json` (主配置, 不动)
- 抓取窗口: `HOURS_WINDOW=24` (.env 控制)
- 输出: `digests/{date}-daily.md` (含每源 摘要+原始条目 details)

### Step 1.5: 跨日去重 (v1.2 自动)

agent.py run() **抓取完成后自动**调用 `dedupe_against_history`, 三层去重:

| 层级 | 规则 | 兜底场景 |
|---|---|---|
| **L1** | URL 完全匹配 (normalized: 去 utm_*/trailing slash) | GitHub Trending 同 repo 连续在榜 |
| **L2** | 标题模糊 (`SequenceMatcher` ratio≥0.85) | Simon datasette 1.0a34→1.0a35 连续版本号 |
| **L3** | GitHub repo 抽取 (`github.com/{u}/{r}`) | URL 重定向导致 L1 miss 的兜底 |

state.json 新增字段 `pushed: [{date, url, title, src}, ...]`, 滑动 **14 天** 自动 trim。

**一次性回填** (从已有 digests/ 重建 history):
```bash
python dedupe.py --init              # 默认 14 天, 自动跳过今天避免污染
```

**dry-run 任意 daily.md 看去重效果**:
```bash
python dedupe.py digests/2026-06-25-daily.md
# 输出: "50 → 45 (去除 5, 10.0%)" + 5 条明细
```

### Step 2: markitdown + manifest 自动生成 (v1.4 重构)

```bash
python markitdown_automate.py 2026-07-03 "" "digests/2026-07-03 md.材料"
# 写 N 个 md + manifest.json
```

**v1.4 关键改动**:
1. **反爬站点 BYPASS** (8 站: qbitai/36kr/juejin/v2ex/simon/latent/hn/reddit) — Python urllib 拿 HTML + 浏览器 UA + 2 次重试
2. **GitHub README 走 api.github.com raw** (markitdown 抓 GitHub UI 是 chrome)
3. **重跑清空旧 md** (防 manifest 漏覆盖)
4. **自动生成 manifest.json** (动态主题映射, 加新源不用改代码)

**manifest.json 格式**:
```json
{
  "01-simon-llm-coding-agent.md": {
    "theme":      "AI 工具与 Agent (能立刻动手)",
    "src_name":   "Simon Willison's Weblog",
    "url":        "https://simonwillison.net/2026/Jul/2/llm-coding-agent/",
    "title_guess":"llm-coding-agent 0.1a0"
  },
  ...
}
```

### Step 3: LLM 总结 (v1.4 智能截断 + 2 段降级)

```bash
python summarize_mds.py 2026-07-03 \
  "./daily-reports/2026-07-03 md.材料" \
  "./daily-reports"
# 写 digests/2026-07-03-summaries.json
```

**v1.4 关键改动**:
1. **优先读 manifest.json** (动态映射), fallback `THEME_MAP` 硬编码
2. **2 段降级**: 主调用 4000 字 → 失败再 2000 字 (跳过 6000, 节省 30%/篇)
3. **`_smart_truncate`** (头 60% + ...[省略]... + 尾 40%) — 防 LLM 拿到残缺 context 返非 JSON

**LLM 输出字段**:
```json
{
  "file":       "01-xxx.md",
  "title":      "<从 md 推断的标题>",
  "url":        "<原 url>",
  "src_name":   "<来源标签>",
  "theme":      "<3 主题之一>",
  "summary":    "<1-2 句讲了什么, ≤80 字>",
  "value":      "<对我们有啥用, ≤80 字>",
  "key_points": ["<3 个 bullet>"],
  "star":       <1-5>,
  "why_read":   "<≤40 字, 读者视角>",
  "pub_date":   "YYYY-MM-DD"
}
```

### Step 4: 渲染 HTML (v1.2 TOP 4 + v1.5 默认版号)

```bash
python report_html_v04.py 2026-07-03 \
  --in  "digests/2026-07-03-summaries.json" \
  --out "digests/2026-07-03-daily-v04.html" \
  --version 1.2
```

**v1.2 关键改动**:
- `TOP_N_PER_THEME = 4` (每主题 4 条, 总 12 条/天)
- 排序: star desc → pub_date desc → 原序
- HTML footer 显示"每主题 TOP 4"

**HTML 关键**:
- 4 tab 切换, **input 必须在 `.panels` 同父** (否则 `~` 选不到)
- 莫兰迪色板 (8 色: bg/surface/surface2/ink/mute/accent/a2/a3/a4/a5)
- 每条 item 5 个区块: meta(序号+star+src+pub_date) → 为什么读 → 这篇讲什么 → 对我们有啥用 → 关键要点 → 末尾溯源

### Step 5: publish 团队目录 (run_daily.py 自动)

run_daily.py 末尾自动 cp 到团队目录, 用新命名规范:
```
半自动日报更新/科技日报V1.0-2026-7-3/      ← 目录
半自动日报更新/科技日报V1.0-2026-7-3/科技日报V1.0-2026-7-3.html
半自动日报更新/科技日报V1.0-2026-7-3/科技日报V1.0-2026-7-3.json
半自动日报更新/科技日报V1.0-2026-7-3/科技日报V1.0-2026-7-3 md.材料/
```

---

## 5. 产物命名

### 5.1 团队目录新规范 (6-22 起, 跑 run_daily.py 默认)

```
半自动日报更新/
├── 科技日报V1.0-2026-7-1\      ← 当天日报 V1.0
├── 科技日报V1.0-2026-7-2\      ← 当天日报 V1.0
└── 科技日报V1.0-2026-7-3\      ← 当天日报 V1.0
```

**月日无前导零** (跟用户原话示例一致: `2026-7-3` 不是 `2026-07-03`)。

### 5.2 同日 V 号递增 (兼容旧 V1.0/V1.1/V1.2 风格)

同日多次更新 → 强制 V1.0 → V1.1 → V1.2 命名, **不静默覆盖**:
```
2026-06-17-daily-V1.0\
2026-06-17-daily-V1.1\
2026-06-17-daily-V1.2\
```

### 5.3 Bitable 规范命名 (运营层, 6-24 用户约定)

不论磁盘文件叫 `科技日报V1.0-2026-7-3.html` / `daily-V1.1.html` 等等, Bitable 的 `日报名` + 飞书云盘附件名一律:
```
科技日报 YYYY-MM-DD.html
```
**Why**: 历史命名混乱, V 号还会涨, 规范化"日报名"让搜索 / 索引稳定。

### 5.4 触发 V 号升级的场景
- LLM 失败重跑
- 用户要求微调 (排版/字段/措辞)
- 漏抓补抓
- 重新分类

### 5.5 不升级的场景
- 同一 V 号内**重跑** (LLM 失败/网络抖) → 仍写同一 V 号, 但要在 commit message 注明
- typo 修正
- 单字段优化

---

## 6. HTML 设计规范

### 6.1 莫兰迪色板 (8 色, 沿用 v0.3)

```python
MORANDI = {
    "bg":       "#F4F1EC",  # 页面背景
    "surface":  "#FBF8F3",  # 卡片背景
    "surface2": "#EDE7DD",  # 分割/边框
    "ink":      "#2E2A26",  # 主文字
    "mute":     "#7A7268",  # 次文字
    "accent":   "#9C8F7E",  # 链接 hover
    "a2":       "#A8B5A0",  # 绿 - 动手
    "a3":       "#C4A484",  # 橙黄 - 提升
    "a4":       "#B5A8A3",  # 粉 - 视野
    "a5":       "#8B9DAA",  # 蓝 - 总览
}
```

### 6.2 3 主题 + brief 文案

| 主题 | 色 | short | slug | brief 文案 (≤30 字) |
|---|---|---|---|---|
| AI 工具与 Agent (能立刻动手) | a2 绿 | 动手 | action | 新模型 / Agent 框架 / 立刻能上手的 coding 工具与工作流 |
| 数据工程与 AI 工程实践 | a3 橙黄 | 提升 | promote | RAG / workflow / 数据处理 / prompt 的工程化踩坑与最佳实践 |
| 行业趋势与战略 (视野与决策) | a4 粉 | 视野 | vision | 报告 / 融资 / 监管 / 商业模式 等行业大势与决策信号 |

### 6.3 4 tab 切换 (CSS-only, 无 JS)

**HTML 结构 (关键: input 与 .panels 同父)**:
```html
<div class="tabbar-wrap tabs-root">
  <input type="radio" name="tab" id="tab-overview" checked>
  <input type="radio" name="tab" id="tab-action">
  <input type="radio" name="tab" id="tab-promote">
  <input type="radio" name="tab" id="tab-vision">
  <nav class="tabbar">
    <label for="tab-overview">总览</label>
    <label for="tab-action">动手</label>
    <label for="tab-promote">提升</label>
    <label for="tab-vision">视野</label>
  </nav>
  <div class="panels">
    <section class="panel" id="panel-overview">...</section>
    <section class="panel" id="panel-action">...</section>
    <section class="panel" id="panel-promote">...</section>
    <section class="panel" id="panel-vision">...</section>
  </div>
</div>
```

**CSS**:
```css
.tabs-root > input { display: none; }
#tab-overview:checked ~ .tabbar label[for="tab-overview"],
#tab-action:checked   ~ .tabbar label[for="tab-action"],
#tab-promote:checked  ~ .tabbar label[for="tab-promote"],
#tab-vision:checked   ~ .tabbar label[for="tab-vision"] {
  color: var(--ink); font-weight: 600; border-bottom-color: var(--a5);
}
#tab-overview:checked ~ .panels #panel-overview,
#tab-action:checked   ~ .panels #panel-action,
#tab-promote:checked  ~ .panels #panel-promote,
#tab-vision:checked   ~ .panels #panel-vision { display: block; }
.panels .panel { display: none; }
```

**Why 同父**: `~` 兄弟选择器不能跨父元素。`input` 必须在 `.panels` 的兄弟链上, 否则 4 个 panel 全 `display:none`。

### 6.4 item 5 区块

```
┌────────────────────────────────────────┐
│ 01  [标题 - 链接到原 url]               │  ← 序号 + 标题
│      [来源] ★★★★☆ 📅 2026-07-03        │  ← meta
│ ────────────────────────────────────   │
│ 💬 为什么读  (斜体底色, ≤40 字)        │  ← why_read
│ ────────────────────────────────────   │
│ 💬 这篇讲什么  (≤80 字)                │  ← summary
│ ────────────────────────────────────   │
│ ⚡ 对我们有啥用  (≤80 字, 加粗)        │  ← value
│ ────────────────────────────────────   │
│ ✓ 关键要点                              │
│   · ...                                 │  ← key_points
│   · ...                                 │
│   · ...                                 │
│ ────────────────────────────────────   │
│              原文溯源 (供核验) →         │  ← 末尾小字
└────────────────────────────────────────┘
```

### 6.5 总览 3 列 grid

```
┌──────────┐ ┌──────────┐ ┌──────────┐
│ 动手 (绿) │ │ 提升 (橙) │ │ 视野 (粉) │
│ 4 条     │ │ 4 条     │ │ 4 条     │
│ 主题名   │ │ 主题名   │ │ 主题名   │
│ brief    │ │ brief    │ │ brief    │
│ 01 标题  │ │ 01 标题  │ │ 01 标题  │
│ 02 标题  │ │ 02 标题  │ │ 02 标题  │
│ 03 标题  │ │ 03 标题  │ │ 03 标题  │
│ 查看 4 条│ │ 查看 4 条│ │ 查看 4 条│
└──────────┘ └──────────┘ └──────────┘
       ↑ 整张卡片是 <label for="tab-X">, 点击跳到对应 tab
```

---

## 7. 核心脚本清单

```
scripts/
├── agent.py                 ← 抓 RSS → digests/{date}-daily.md (v1.4 禁代理 patch)
├── llm_client.py            ← LLM 客户端 (v1.4 timeout 60s)
├── markitdown_automate.py   ← (v1.4 新增) md 转换 + manifest.json
├── summarize_mds.py         ← LLM 总结 (v1.4 _smart_truncate + _load_manifest)
├── report_html_v04.py       ← 渲染单文件 HTML (v1.2 TOP 4)
├── dedupe.py                ← 跨日去重 (v1.2 state.pushed 14 天)
├── run_daily.py             ← (v1.4 新增) 5 步一键编排 + publish
├── run_daily.bat            ← (v1.4 新增) Windows 一键跑
├── install_cron.bat         ← (v1.4 新增) schtasks 注册
└── digests/                 ← 中间产物 (git ignore)
```

### 7.1 完整调用链

```bash
# ─── 准备工作 ───
cp config/.env.example .env
# 编辑 .env, 填 LLM_API_KEY
cp config/sources.example.json sources.json  # 可保持默认
pip install -r config/requirements.txt       # requests, beautifulsoup4, feedparser

# ─── 一键跑 (推荐) ───
cd scripts/
python run_daily.py 2026-07-03
# 自动: agent → markitdown → summarize → html → publish

# ─── 分步跑 (debug 用) ───
cd scripts/
python agent.py 2026-07-03                                       # Step 1
python markitdown_automate.py 2026-07-03 "" "digests/2026-07-03 md.材料"  # Step 2
python summarize_mds.py 2026-07-03 \
  "digests/2026-07-03 md.材料" "digests"                         # Step 3
python report_html_v04.py 2026-07-03 \
  --in "digests/2026-07-03-summaries.json" \
  --out "digests/2026-07-03-daily-v04.html" \
  --version 1.2                                                   # Step 4
# Step 5: publish 团队目录 (run_daily.py 自动, 分步跑要手 cp)
```

### 7.2 Windows 任务计划 (一键注册)

```cmd
cd scripts
install_cron.bat
REM 注册任务 "DailyDigestAgent", 每天 08:00 触发 run_daily.bat
REM (需要管理员权限, 失败改用 /ru SYSTEM /rl highest)
```

### 7.3 升级 V 号的复用流程

```bash
# 假设 V1.0 已存在, 现在做 V1.1
V="1.1"
cp -r "../半自动日报更新/科技日报V1.0-2026-7-3" "../半自动日报更新/科技日报V${V}-2026-7-3"

# 重跑 step 3 + 4, 写到 V1.1
python summarize_mds.py 2026-07-03 \
  "digests/2026-07-03 md.材料" "."
python report_html_v04.py 2026-07-03 \
  --in "2026-07-03-summaries.json" \
  --out "科技日报V1.1-2026-7-3.html" \
  --version 1.1
```

---

## 8. 运营脚本清单 (飞书 DM + Bitable)

```
ops/                        ← 运营层 (跟核心 scripts/ 分离, 方便同事不看 pipeline 直接用)
├── send_daily_report.py    ← 飞书 SDK 上传 + DM file 消息
├── send_daily_report.bat   ← Windows 一键发 (含 3 坑修复)
├── sync_to_bitable.py      ← 飞书云盘 + Bitable 多维表格同步
├── verify_bitable_sync.py  ← 硬验证 (4 状态码)
├── verify_and_recover.bat  ← 10:40 兜底 (缺/不规范 → 自动 re-send)
├── _send_daily_scan.ps1    ← 扫今天目录 + 串 3 个 py (双 verify 嵌套)
└── BRIEF_科技日报自动化.md ← 投递 agent ↔ Clove 协作版 BRIEF
```

### 8.1 完整调用链

```cmd
REM 1. 准备凭证 (agent python 自带 lark-oapi + pyyaml)
REM    ~/.daily-digest/config.yaml 的 platforms.feishu.extra.app_id / app_secret

REM 2. 跑 (有 3 种模式)
send_daily_report.bat                                  REM Mode 2: 扫今天目录自动发
send_daily_report.bat "C:\path\daily.html" --dry-run   REM Mode 1: 发指定文件 (dry-run 不真发)
send_daily_report.bat "C:\path\daily.html"             REM Mode 1: 发指定文件

REM 3. 同步 Bitable (规范化命名 + create/update)
python sync_to_bitable.py "C:\path\daily.html" --dry-run

REM 4. 硬验证 (4 状态码: 0=OK / 1=MISSING / 2=MISMATCH / 3=API_ERROR)
python verify_bitable_sync.py 2026-07-03

REM 5. 兜底 (10:40 cron, 缺/不规范 → 自动重发 + 再 verify)
verify_and_recover.bat
```

### 8.2 schtasks 注册

```cmd
REM 10:10 自动扫今天日报
schtasks /create /tn "投递 agent-DailyReportSend" ^
  /tr "./daily-reports\_scripts\send_daily_report.bat" ^
  /sc daily /st 10:10 /f

REM 10:40 兜底
schtasks /create /tn "投递 agent-DailyReportVerify" ^
  /tr "./daily-reports\_scripts\verify_and_recover.bat" ^
  /sc daily /st 10:40 /f
```

### 8.3 飞书凭证

```yaml
# ~/.daily-digest/config.yaml
platforms:
  feishu:
    extra:
      app_id: cli_xxxx
      app_secret: xxxx
```

收件人 DM `chat_id = oc_<your_dm_chat_id>` (其他用户换自己)。

### 8.4 Bitable 字段

```
app_token  = <your_bitable_app_token>
table_id   = tblsFKNsqv3oOT6b
日报日期    (Text)         - "2026-07-03" (单 key)
日报名      (Text)         - "科技日报 2026-07-03"
产出类型    (MultiSelect)  - 固定 ["Html"]
产出        (Attachment)   - drive 媒体资源
```

去重策略: 按"日报日期"单 key 命中 → skip (规范名一致) 或 update (规范名不一致)。不靠文件名去重。

---

## 9. 常见坑 + workaround (v1.5 增 8 条)

### 9.1 GitHub README: markitdown 抓 UI chrome 不是 README

**症状**: `markitdown https://github.com/user/repo` 输出是 GitHub 网站 UI。

**Fix** (v1.4 已内置 `markitdown_automate.py`):
- GitHub URL 走 `api.github.com/repos/{u}/{r}/readme` raw 端点 + `Accept: application/vnd.github.raw`
- 注: GitHub API **60 req/h 限流**, 一次跑 7 个 trending + HN 评论 + 仓库 README 容易触发

### 9.2 量子位 / 36 氪 / 掘金: 403 反爬 + curl 走 WinHTTP 代理

**症状**: `markitdown https://www.qbitai.com/...` 报 403 / `curl exit 35 SSL connect error`。

**Fix** (v1.4 已内置 `BYPASS_MARKITDOWN_FETCH` 8 站):
```python
BYPASS_MARKITDOWN_FETCH = (
    "qbitai.com", "36kr.com", "juejin.cn",
    "v2ex.com", "simonwillison.net", "latent.space",
    "news.ycombinator.com", "reddit.com",
)
# 强制走 Python urllib 拿 HTML + 浏览器 UA + 2 次重试 → markitdown tmp.html
```

### 9.3 LLM 422 Unprocessable Entity (body 太长)

**症状**: 大段中文文章 (qbitai 1万字+) LLM 返 422 / 非 JSON。

**Fix** (v1.4 已内置):
1. **`_smart_truncate`** 头 60% + ...[省略]... + 尾 40%
2. **2 段降级**: 主调用 4000 字 → 失败再 2000 字

### 9.4 LLM JSONDecodeError (含 `<think>` 块 / markdown 围栏)

**症状**: LLM 返回含 `<think>` 块 / ```json``` 围栏, json.loads 失败。

**Fix** (summarize_mds 已内置):
```python
content = re.sub(r"<think>.*?</think>", "", content, flags=re.S)  # 去 think 块
if content.startswith("```"):
    content = content.split("```", 2)[1]
    if content.startswith("json"):
        content = content[4:]  # 去 ```json\n\n 围栏
```

### 9.5 LLM timeout 15s 太短 (MiniMax M3 长 prompt 慢响应)

**症状**: 长 prompt (4K+ body) MiniMax M3 处理慢, 经常 hang 30s+, 15s 超时 → fallback。

**Fix** (v1.4 已内置 `llm_client.py:44`): `chat(... timeout: float = 60.0)`, 默认值从 15s 提到 60s。

### 9.6 Windows 系统代理 127.0.0.1:7890 挂了

**症状**: 用户机器 Clash/V2Ray 没启动, 但系统级代理设置还在; agent.py 报 `ProxyError HTTPSConnectionPool 127.0.0.1:7890` → 0 条。

**Fix** (v1.4 已内置 `agent.py:11-18`):
```python
import urllib.request as _urllib_request
_urllib_request.getproxies = lambda: {}  # 覆盖 feedparser 用的代理
requests.sessions.Session.trust_env = False  # 覆盖 requests 用的代理
```
**Why**: requests 走 WinHTTP 注册表读代理, feedparser 走 urllib.getproxies, 两处都要禁。

### 9.7 markitdown 重跑漏覆盖 → manifest 错位

**症状**: 重跑时 md.材料/ 目录有上次残留 md (同名但内容不同), manifest.json 只覆盖本次新抓 URL, 旧 md 文件名不在 manifest → summarize 走 THEME_MAP 硬编码 fallback → ("未分类", filename, "")。

**Fix** (v1.4 已内置 `markitdown_automate.py:201-209`):
```python
old_md = list(out_dir.glob("*.md"))
for p in old_md:
    try: p.unlink()
    except OSError: pass
# 不删 manifest.json, 下面会重写
```

### 9.8 Path("") 误判 Path(".")

**症状**: `markitdown_automate.py [date] [daily_md] [md_dir]`, 当 `daily_md=""` 时, `Path("")` 等价 `Path(".")`, 会误判为"用当前目录"。

**Fix** (v1.4 已内置 `markitdown_automate.py:194-195`):
```python
daily_md = daily_md if (daily_md and str(daily_md) not in (".", "")) else None
```

### 9.9 Windows GBK console 崩溃

**症状**: `print("✅")` 报 UnicodeEncodeError。

**Fix**: print 用 ASCII-safe 字符
```python
print(f"[summarize] OK {json_path}")  # 不用 ✅/💡/⭐
```

### 9.10 CSS tab 兄弟选择器: 内容空白

**症状**: tab 切换后 panel 内容不显示, 控制台无错。

**Fix**: `<input>` 必须跟 `.panels` **同父** (在 `.tabbar-wrap` 顶层, 不要嵌进 `.tabbar`), `~` 才能跨过中间的 `<nav>` 命中 `.panels`。

### 9.11 title 提取抓 logo/文件列表

**症状**: 提取的标题是 "├── xxx.py" 或 "Star History"。

**Fix** (summarize_mds._extract_title):
- H1 跳过: `len<5` / `├──` / `└──` / 含 `.` 和 `/`
- H2 跳过列表: "Star History", "License", "Contributors", "About", "Releases", "Footer", "Links", "项目结构", "目录结构", "致谢" 等
- H2 跳过前缀: "From the creator of"

### 9.12 LLM key 在 .env 误填 .chat SSL 错

**症状**: `LLM_API_BASE=https://api.MiniMax.chat` 报 SSL 错。

**Fix**: MiniMax 端点是 `https://api.minimaxi.com` (注意是 `.com` 不是 `.chat`)

### 9.13 跨日重复 (GitHub Trending / HN frontpage / 大会连续报道) ← v1.2

**症状**: 6-24 日报和 6-23 日报有 5/50 条资料重合。

**Fix** (v1.2 已内置): Step 1.5 自动 dedupe + Step 6 自动 record_pushed + 一次 init。

**坑中坑**: 第一版 `--init` 没排除今天 → 当天 daily.md 被回填进 state.pushed → dry-run 全命中假阳性。修复: `init_from_digests(exclude_today=True)` 默认行为。

### 9.14 飞书 file_type 必须是 stream (HTML)

**症状**: `file_type="html"` 报 234001 Invalid request param。

**Fix** (ops/send_daily_report.py 已内置): HTML 走 `file_type="stream"` (通用流)。

### 9.15 飞书 list_message 时间戳用毫秒

**症状**: 传 "2026-06-18 14:00:00" 字符串 → 230001 错。

**Fix**: 毫秒 int: `int(time.mktime(...) * 1000)`。

### 9.16 Python 路径版本敏感 (Windows)

**症状**: 升级 agent 后 `%USERPROFILE%\.agent-web-ui\desktop-runtime\agent\0.15.2\win-x64\python\python.exe` 里的版本号变 (0.15.2 → 0.15.3)。

**Fix**: bat 第一行改版本号, 加注释 `REM 升级 agent 后改下一行`。

### 9.17 bat GBK 编码 + 中文路径

**症状**: cmd.exe 默认 GBK, 写 UTF-8 bat 会 rc=255。

**Fix**:
- bat 用 cp936/ANSI 编码
- 中文路径用 `powershell -NoProfile -Command "..."` 算 (locale-safe)
- ISO timestamp 用 `powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"` (不要 wmic, 11 已废)

### 9.18 schtasks 锁屏不跑

**症状**: 任务计划默认"只使用交互方式" → 锁屏/未登录时任务不触发。

**Fix**: 管理员 `schtasks /create /ru SYSTEM /rl highest` (需 admin)。

### 9.19 wsl.exe 弹窗 (terminal 触发)

**症状**: 投递 agent `terminal` 工具底层 git-bash/MSYS 启动时触发 `wsl.exe --update` 弹窗, 命令返乱码。

**Fix**: schtasks 直接调 bat, 绕过 agent agent shell。

### 9.20 Bitable 命名混乱 (V 号不一致)

**症状**: 磁盘文件 `科技日报V1.0-2026-6-24.html` / `daily-V1.1.html` 都进 Bitable, 命名五花八门。

**Fix** (ops/sync_to_bitable.py 已内置): 解析 date + version, Bitable 一律规范化"科技日报 YYYY-MM-DD.html"。

---

## 10. 验收 checklist

### 10.1 文件完整性
- [ ] `科技日报V1.0-YYYY-M-D.html` 存在, 大小 50-55 KB
- [ ] `科技日报V1.0-YYYY-M-D.json` 存在, 含 12 条 (每主题 4 条)
- [ ] `科技日报V1.0-YYYY-M-D md.材料/` 含 N 个 md + `manifest.json`
- [ ] V1.0 (旧版) 仍在, 未被覆盖 (如存在 V1.1)

### 10.2 HTML 视觉
- [ ] 顶部 4 tab 可见: 总览 / 动手 / 提升 / 视野, 莫兰迪色
- [ ] 点击 tab 能切换 panel (4 个 panel 内容互不重叠)
- [ ] 总览 panel 显示 3 张概览卡 (列网格)
- [ ] 主题 panel 每个 item 有 4-5 区块 (为什么读 / 这篇讲什么 / 对我们有啥用 / 关键要点)
- [ ] 每个 item 头部有 ★ + 📅 标签
- [ ] 末尾有"原文溯源"小字链接
- [ ] footer 显示"每主题 TOP 4"

### 10.3 偏好字段
- [ ] **star**: 12 条都有 1-5 整数, 显示 ★/☆
- [ ] **why_read**: 12 条都有 ≤40 字
- [ ] **pub_date**: ≥10 条有 YYYY-MM-DD (GitHub README 偶尔推断不出可空)

### 10.4 内容质量
- [ ] summary 不含 markdown 噪音 (日期/`0`/`阅读12分钟`)
- [ ] 标题真实, 不含 "├──" / "Star History" / "License" 等
- [ ] LLM 失败数 ≤ 1 (fallback 标记)
- [ ] 链接到原 url 可打开

### 10.5 命名
- [ ] 团队目录用新规范 `科技日报V1.0-YYYY-M-D\` (月日无前导零)
- [ ] 旧 V1.x 命名兼容, 升级用 V1.0 → V1.1 → V1.2
- [ ] md.材料子目录用 `V{major}.{minor} md.材料\` 或 `{base} md.材料\`

### 10.6 跨日去重 (v1.2 新增)
- [ ] `state.json` 含 `pushed` 字段 (≥10 条, 长度不超过 14 天滑动窗口)
- [ ] agent.py run() 日志显示 `[OK] 去重: 抓 N → 留 M (去除 K 条跨日重复)`, K 通常 3-10 条

### 10.7 运营层 (v1.5 新增)
- [ ] 10:10 飞书 DM 收到 HTML 附件 (附件名"科技日报 YYYY-MM-DD.html")
- [ ] Bitable 科技日报-每日更新 有当天记录, 日报名 = "科技日报 YYYY-MM-DD"
- [ ] 10:40 verify_and_recover.bat 双 verify 嵌套, exit 0
- [ ] 跨天日 10:10 自动 skip 重发 (Bitable 已有规范名)

### 10.8 启动层 (v1.4 新增)
- [ ] agent.py:11-18 禁系统代理 patch 在
- [ ] llm_client.py:44 timeout 60s 在
- [ ] summarize_mds.py:208-219 _smart_truncate 在
- [ ] markitdown_automate.py:103-160 _http_get_no_proxy 在
- [ ] markitdown_automate.py:201-209 清空旧 md 在

---

## 11. 3 段时间窗 (实测稳定 6-30 → 7-3, 4 天全 rc=0)

```
09:50  Clove / Clove-like  跑 run_daily.py
                          → 半自动日报更新/科技日报V1.0-2026-7-3/
10:10  投递 agent / Clove-like   跑 send_daily_report.bat (Mode 2: 扫今天目录)
                          → 飞书 DM 收件 (收件人 chat_id=oc_<your_dm_chat_id>)
                          → sync_to_bitable.py 同步 Bitable
                          → verify_bitable_sync.py 硬验证 (rc=0)
10:40  投递 agent / Clove-like   跑 verify_and_recover.bat
                          → 缺/不规范 → 自动 re-send + 再 verify
                          → 双 verify 嵌套
```

**双 verify 嵌套** (7-2 加固):
- 10:10 一次 verify (在 send_daily_report.bat 末尾)
- 10:40 一次 verify + 失败 re-send (在 verify_and_recover.bat)
- 两次都 `rc=0` 才算当天天 OK

**实测 log** (2026-07-03):
```
=== 2026-07-03 10:10:02 bat start ===
[scan] dir=科技日报V1.0-2026-7-3  file=科技日报V1.0-2026-7-3.html
[creds] app_id=cli_<your_app_id> chat_id=oc_<your_dm_chat_id>
[upload] 科技日报 2026-07-03.html (51983 bytes)
[upload] OK file_key=file_v3_<your_file_key>
[send] OK message_id=om_x100b6b45ef5ba074c318e5e8cf5fb50
[create] OK record_id=recvogVAKuqqrq
[verify] OK record_id=recvogVAKuqqrq name='科技日报 2026-07-03' size=51983
=== 2026-07-03 10:10:44 bat end rc=0 ===

=== 2026-07-03 10:40:02 10:40 verify-and-recover start ===
[verify] target_date=2026-07-03
[verify] OK record_id=recvogVAKuqqrq
=== 2026-07-03 10:40:02 10:40 verify OK (already in Bitable
```

---

## 📎 附录

### A. 8 个核心脚本的快速索引

| 脚本 | 入口 | 关键函数 | 输入 | 输出 |
|---|---|---|---|---|
| `agent.py` | `run()` | `fetch_rss`, `fetch_github_trending`, `dedupe_against_history` | `sources.json` | `digests/{date}-daily.md` |
| `llm_client.py` | `chat()` | OpenAI 兼容 chat (timeout 60s) | messages list | content 字符串 |
| `markitdown_automate.py` | `run()` | `_http_get_no_proxy`, `_markitdown_one`, 自动写 `manifest.json` | `digests/{date}-daily.md` | `digests/{date} md.材料/` |
| `summarize_mds.py` | `run(date, md_dir, out_dir)` | `_summarize_one`, `_smart_truncate`, `_load_manifest` (2 段降级) | `*.md` N 个 | `summaries.json` |
| `report_html_v04.py` | `render(date, in, out, version)` | `build_html`, TOP_N_PER_THEME=4 | summaries.json | 单文件 HTML |
| `dedupe.py` | `dedupe_against_history` | L1/L2/L3 三层去重, state.pushed 14 天 | items | (kept, dropped) |
| `run_daily.py` | `main()` | 5 步一键编排 + publish 团队目录 | date | 团队目录 + 文件 |
| `run_daily.bat` | (cmd 入口) | 调 python run_daily.py | args | rc |

### B. 7 个运营脚本的快速索引

| 脚本 | 入口 | 关键函数 | 输入 | 输出 |
|---|---|---|---|---|
| `send_daily_report.py` | `main()` | 飞书 SDK upload + DM file msg | html_path | rc=0 |
| `send_daily_report.bat` | (cmd 入口) | Mode 1: 发指定 / Mode 2: 扫今天 | args | rc |
| `sync_to_bitable.py` | `main()` | 规范化命名 + create/update Bitable | html_path | rc=0 |
| `verify_bitable_sync.py` | `main()` | 4 状态码 (0/1/2/3) | date_str | rc |
| `verify_and_recover.bat` | (cmd 入口) | 10:40 兜底, 双 verify 嵌套 | none | rc |
| `_send_daily_scan.ps1` | (ps 入口) | 扫今天目录 + 串 3 个 py | env | rc |
| `install_cron.bat` | (cmd 入口) | schtasks 注册 run_daily.bat | none | rc |

### C. 相关 memory

- [[daily-digest-pipeline]] — 项目档案
- [[daily-digest-v14-cross-iter]] — v1.4 跨代改 5 项 (禁代理/timeout 60s/_smart_truncate/_load_manifest/反爬)
- [[daily-digest-cross-day-dedupe]] — v1.2 跨日去重
- [[daily-digest-llm-fallback-chain]] — 6-26 LLM fallback 4 类根因
- [[daily-digest-markitdown-anticrawl]] — 6-29 反爬根因
- [[daily-digest-send-bitable-ops]] — 7-2 Bitable 加固 + 10:40 兜底
- [[versioning-convention]] — V1.x 命名规则
- [[source-screening-method]] — 信源池维护
- [[single-file-report-skill]] — markitdown 通用方法
- [[visual-icon-style]] — 莫兰迪 + SVG icon
- [[windows-schtasks-bat-pitfalls]] — bat 3 坑 (GBK/EnableDelayedExpansion/\0 NUL)
- [[agent-python-deps]] — agent python 路径 + bs4/feedparser/requests

### D. 版本

- **v1.5 (2026-07-03)**: v1.4 跨代改 5 项打包 + 7 运营脚本独立成 `ops/` + run_daily.py 一键编排 + 3 段时间窗
- v1.4 (2026-06-29): 禁系统代理 + timeout 60s + _smart_truncate + _load_manifest + 反爬 8 站 (markitdown_automate.py)
- v1.3 (2026-06-26): LLM fallback 4 类根因修复 (timeout / 截断 / 清 md / dedupe)
- v1.2 (2026-06-24): 跨日去重 (Step 1.5 dedupe + Step 6 record_pushed + state.pushed 14 天滑动)
- v1.1 (2026-06-17): 升级加 tab 切换 + 3 偏好字段
- v1.0 (2026-06-17): 3 主题卡片, markitdown + LLM 总结
- v0.3: 5 信源分组, RSS 摘要 (旧)
- v0.1: 1 文件 markdown 摘要 (最旧)
