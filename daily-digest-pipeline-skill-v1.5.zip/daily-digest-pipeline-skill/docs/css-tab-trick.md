# CSS-only tab 切换: 兄弟选择器同父约束

> **核心结论**: `<input type="radio">` 必须跟 `<div class="panels">` **同父**, 否则 `~` 选不到 panel, 4 个 panel 全 `display:none`。

## ❌ 错误结构 (踩过的坑)

```html
<div class="tabbar-wrap">
  <div class="tabbar">
    <input type="radio" id="tab-overview" checked>
    <label for="tab-overview">总览</label>
    ...
  </div>
  <div class="panels">
    <section class="panel" id="panel-overview">...</section>
    ...
  </div>
</div>
```

```css
#tab-overview:checked ~ .panels #panel-overview { display: block; }   /* ❌ 不生效 */
```

**Why 不生效**: `~` 是**兄弟选择器**, 只能选同父的同辈元素。
- `input#tab-overview` 的父是 `.tabbar`
- `.panels` 的父是 `.tabbar-wrap`, 不是 `.tabbar`
- `~` 跨不过父元素

控制台表现: tab 视觉正常 (label 可点), 但 4 个 panel 区域**永远是空的** (只看到一条横线)。

## ✅ 正确结构

```html
<div class="tabbar-wrap tabs-root">
  <input type="radio" name="tab" id="tab-overview" checked>
  <input type="radio" name="tab" id="tab-action">
  <input type="radio" name="tab" id="tab-promote">
  <input type="radio" name="tab" id="tab-vision">
  <nav class="tabbar">
    <label for="tab-overview">总览</label>
    <label for="tab-action">动手</label>
    <label for="tab-promote">提升</label>
    <label for="tab-vision">视野</label>
  </nav>
  <div class="panels">
    <section class="panel" id="panel-overview">...</section>
    <section class="panel" id="panel-action">...</section>
    <section class="panel" id="panel-promote">...</section>
    <section class="panel" id="panel-vision">...</section>
  </div>
</div>
```

```css
.tabs-root > input { display: none; }
#tab-overview:checked ~ .tabbar label[for="tab-overview"],
#tab-action:checked   ~ .tabbar label[for="tab-action"],
#tab-promote:checked  ~ .tabbar label[for="tab-promote"],
#tab-vision:checked   ~ .tabbar label[for="tab-vision"] {
  color: var(--ink); font-weight: 600; border-bottom-color: var(--a5);
}
#tab-overview:checked ~ .panels #panel-overview,
#tab-action:checked   ~ .panels #panel-action,
#tab-promote:checked  ~ .panels #panel-promote,
#tab-vision:checked   ~ .panels #panel-vision { display: block; }
.panels .panel { display: none; }
```

**关键点**:
- `input` 跟 `.panels` 同父 (`tabs-root`)
- `input` 之间的 `~` 也能跨过中间 `<nav>` (因为同辈), 命中 `.panels`
- `display: none` 默认 + `checked` 时 `display: block` 显隐

## 🎨 Sticky 顶栏

如果要让 tab 行吸顶, 给 `.tabbar-wrap` 加:

```css
.tabbar-wrap {
  position: sticky;
  top: 0;
  z-index: 50;
  background: var(--bg);
  padding: 8px 0 0;
  margin: 0 -24px 20px;     /* 抵消 .wrap 的 padding-left, 让底线通栏 */
  border-bottom: 1px solid var(--surface2);
}
```

## 🖨 打印优化

打印时让所有 panel 强制显示:

```css
@media print {
  .tabbar-wrap { position: static; }
  .panels .panel { display: block !important; page-break-after: always; }
}
```

## 备选: 用 JS 切换 (不推荐)

如果哪天 `:has()` 兼容性出问题或纯 CSS 不够用, JS 也很简单:

```js
document.querySelectorAll('.tabbar input').forEach(r => {
  r.addEventListener('change', () => {
    document.querySelectorAll('.panels .panel').forEach(p => p.style.display = 'none');
    const panel = document.getElementById('panel-' + r.id.replace('tab-', ''));
    if (panel) panel.style.display = 'block';
  });
});
```

**但纯 CSS 优先**: 离线单文件 HTML, 任何环境 (沙盒/无 JS) 都能用。
