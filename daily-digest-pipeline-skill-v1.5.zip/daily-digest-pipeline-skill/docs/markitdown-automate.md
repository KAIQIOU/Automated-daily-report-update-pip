# markitdown_automate.py · v1.4 反爬 + manifest 自动生成

> 把 `digests/{date}-daily.md` 里的 URL **自动**转 md, 同时写 `manifest.json` 供 `summarize_mds.py` 用。

## 为什么不用 markitdown URL 直转

直接 `markitdown https://www.qbitai.com/2026/06/xxx.html` 有 2 类问题:

1. **403 反爬**: 中文站 (qbitai/36kr/juejin) 检测 UA 拒绝, 通用浏览器 UA 都不行
2. **curl 走 WinHTTP 代理**: Windows 11 系统代理 127.0.0.1:7890 (clash 挂) → `exit 35 SSL connect error`

**v1.4 解决方案** (`markitdown_automate.py:103-160`):
- 8 站 (BYPASS_MARKITDOWN_FETCH) 强制走 **Python urllib** 拿 HTML (subprocess curl 无法禁 WinHTTP 代理)
- 浏览器 UA + 2 次重试 (1.5s/3s 退避)
- 落临时文件 → markitdown tmp.html → 删 tmp
- GitHub README 走 `api.github.com/repos/{u}/{r}/readme` raw 端点

## 反爬站点白名单

```python
BYPASS_MARKITDOWN_FETCH = (
    "qbitai.com", "36kr.com", "juejin.cn",
    "v2ex.com", "simonwillison.net", "latent.space",
    "news.ycombinator.com", "reddit.com",
)
```

**加新站**: 跑 `curl -sL -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" <url>` 看是否 403, 是就加进 `BYPASS_MARKITDOWN_FETCH`。

## 重跑清空旧 md (v1.4 修复)

**症状**: 重跑时 md.材料/ 目录有上次残留 md (同名但内容不同), `manifest.json` 只覆盖本次新抓 URL, 旧 md 文件名不在 manifest → `summarize_mds.py` 走 `THEME_MAP` 硬编码 fallback → ("未分类", filename, "")。

**Fix** (`markitdown_automate.py:201-209`):
```python
old_md = list(out_dir.glob("*.md"))
for p in old_md:
    try: p.unlink()
    except OSError: pass
if old_md:
    print(f"[markitdown_auto] 清空旧 md × {len(old_md)} (防 manifest fallback)")
```

## manifest.json 自动生成 (v1.4 新增)

**用途**: 给 `summarize_mds.py` 动态读 theme/src_name/url, **加新源不用改 `THEME_MAP` 硬编码**。

**格式** (`md.材料/manifest.json`):
```json
{
  "01-simon-llm-coding-agent.md": {
    "theme":       "AI 工具与 Agent (能立刻动手)",
    "src_name":    "Simon Willison's Weblog",
    "url":         "https://simonwillison.net/2026/Jul/2/llm-coding-agent/",
    "title_guess": "llm-coding-agent 0.1a0"
  },
  ...
}
```

**主题推断** (`SRC_THEME_KEYS` 关键词):
| 关键词 | 主题 |
|---|---|
| qbitai / 36kr / 量子位 | 行业趋势与战略 (视野与决策) |
| github / hacker / hn / simon / latent / r/ai | AI 工具与 Agent (能立刻动手) |
| juejin / 掘金 / v2ex / anthropic / claude | 数据工程与 AI 工程实践 |
| (default) | 数据工程与 AI 工程实践 |

**加新源**: 在 `markitdown_automate.py:SRC_THEME_KEYS` 加一行 `(关键词, 主题)` 即可。

## Path("") 误判 Path(".") 修复

**症状**: `markitdown_automate.py [date] [daily_md] [md_dir]`, 当 `daily_md=""` 时, `Path("")` 等价 `Path(".")`, 会误判为"用当前目录"。

**Fix** (`markitdown_automate.py:194-195`):
```python
daily_md = daily_md if (daily_md and str(daily_md) not in (".", "")) else None
out_dir  = out_dir  if (out_dir  and str(out_dir)  not in (".", "")) else None
```

## 用法

```bash
# 默认 (date=today, daily_md=digests/{date}-daily.md, out_dir=digests/{date} md.材料)
python markitdown_automate.py

# 指定 date
python markitdown_automate.py 2026-07-03

# 指定全部
python markitdown_automate.py 2026-07-03 "digests/2026-07-03-daily.md" "C:/tmp/md.材料"
```

## 已知边界

- **GitHub API 60 req/h 限流** — 一次跑 7 个 trending + HN 评论 + 仓库 README 容易触发 → fall back 到 URL 直转 (会拿到 UI chrome, summarize 走 fallback)
- **HN/phanta 慢响应** — 3 次重试 × 30s 还 timeout 是常态, 当 FAIL 处理
- **juejin 404** — 真链接失效 (post 数字不存在), 不是反爬
- **markitdown 失败不阻塞**: md size < 500 算 FAIL, summarize 走 fallback "见原文" 继续
