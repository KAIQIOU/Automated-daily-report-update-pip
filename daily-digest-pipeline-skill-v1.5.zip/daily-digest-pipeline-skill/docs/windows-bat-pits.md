# Windows bat / schtasks 6 大坑 (跨项目通用)

> send_daily_report.bat + verify_and_recover.bat + install_cron.bat 踩过的 6 个坑, 跨项目通用, 详细见 [[windows-schtasks-bat-pitfalls]]。

## 坑 1: Python 路径会变

```cmd
REM ❌ 升级 agent 后路径里版本号变, 但 bat 没改
set "HERMES_PY=%USERPROFILE%\.agent-web-ui\desktop-runtime\agent\0.15.2\win-x64\python\python.exe"
```

**Fix** (顶部加注释):
```cmd
REM ============================================================
REM  升级 agent 后改下一行: 0.15.2 改成新版本号
REM ============================================================
set "HERMES_PY=%USERPROFILE%\.agent-web-ui\desktop-runtime\agent\0.15.2\win-x64\python\python.exe"
```

**Why**: agent 是 agent-web-ui 的 embedded python, 升级后版本号变 (0.15.2 → 0.15.3), 路径失效。

## 坑 2: bat GBK 编码 + 中文路径

**症状**: cmd.exe 默认 GBK, 写 UTF-8 bat 会 rc=255。

**Fix**:
- bat 用 cp936/ANSI 编码 (不是 UTF-8)
- 中文路径用 `powershell -NoProfile -Command "..."` 算 (locale-safe)
- 不要在 bat 里直接 echo 中文

## 坑 3: ISO timestamp 必须 powershell (wmic 11 已废)

```cmd
REM ❌ wmic 在新版 Windows 11 已废弃
for /f "delims=" %%I in ('wmic os get localdatetime /value') do set TS=%%I

REM ✅ powershell 替代
for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"') do set TS=%%I
```

**Why**: wmic 在 Windows 11 24H2 起 deprecate, powershell 是 locale-safe。

## 坑 4: EnableDelayedExpansion (循环里变量不展开)

**症状**:
```cmd
setlocal
set "FOUND_DIR="
for /d %%d in ("%BASE%\%TODAY%-daily-V*") do (
    if not defined FOUND_DIR (
        set "FOUND_DIR=%%d"     REM ❌ 不会展开, 一直是空
    )
)
```

**Fix**:
```cmd
setlocal EnableDelayedExpansion
set "FOUND_DIR="
for /d %%d in ("%BASE%\%TODAY%-daily-V*") do (
    if not defined FOUND_DIR (
        set "FOUND_DIR=%%d"
    )
)
echo !FOUND_DIR!                REM ✅ !FOUND_DIR! 才展开
```

**Why**: 循环里 `set` 在 `()` 块里默认延迟展开, 必须用 `!` 而不是 `%`。

## 坑 5: schtasks 锁屏不跑

**症状**: 任务计划默认"只使用交互方式" → 锁屏/未登录时任务不触发。

**Fix** (需要管理员):
```cmd
schtasks /create /tn "MyTask" /tr "..." /sc daily /st 10:10 /ru SYSTEM /rl highest /f
```

**Why**: `/ru SYSTEM` 让任务以 SYSTEM 身份跑 (无需用户登录), `/rl highest` 最高权限。

## 坑 6: wsl.exe 弹窗 (terminal 触发)

**症状**: 投递 agent `terminal` 工具底层 git-bash/MSYS 启动时触发 `wsl.exe --update` 弹窗, 命令返乱码。

**Fix**: schtasks 直接调 bat, 绕过 agent agent shell。
```cmd
REM ❌ 在 agent agent 里跑 bat (触发 wsl 弹窗)
& bat_file

REM ✅ schtasks 注册, 后台跑
schtasks /create /tn "MyTask" /tr "bat_file" /sc daily /st 10:10 /f
schtasks /run /tn "MyTask"
```

## 附加坑 (飞书 + LLM)

### 坑 7: 飞书 file_type 必须是 stream (HTML)

```python
# ❌ 返 234001 Invalid request param
file_type="html"

# ✅ HTML 走 stream (通用流)
file_type="stream"
```

固定可选: `opus | mp4 | pdf | doc | xls | ppt | stream`。

### 坑 8: list_message 时间戳用毫秒

```python
# ❌ 字符串返 230001
start_time = "2026-06-18 14:00:00"

# ✅ 毫秒 int
start_ms = int(time.mktime(time.strptime("2026-06-18 14:00:00", "%Y-%m-%d %H:%M:%S")) * 1000)
```

### 坑 9: Windows 系统代理 127.0.0.1:7890 (clash 挂)

**症状**: 用户机器 Clash/V2Ray 没启动, 但系统级代理设置还在; `requests` 走 WinHTTP 注册表读代理, 报 `ProxyError HTTPSConnectionPool 127.0.0.1:7890` → 0 条。

**Fix** (Python 启动时禁代理):
```python
import urllib.request as _urllib_request
_urllib_request.getproxies = lambda: {}  # 覆盖 feedparser 用的代理
requests.sessions.Session.trust_env = False  # 覆盖 requests 用的代理
```

**Why**: requests 从 WinHTTP 注册表读代理, 不是从 os.environ 读; subprocess 调 curl 无法禁 WinHTTP 代理, 必须进程内 Python urllib。

### 坑 10: `\0` NUL 字符

**症状**: bat 输出 `\0` 会让 schtasks 假死。

**Fix**: 不要在 bat 里 echo 含有 NUL 的二进制内容 (如 `set` 注入变量时加 `for /f` 过滤)。

## 调试技巧

### 看 schtasks 上次运行结果

```cmd
schtasks /query /tn "MyTask" /fo LIST /v
```

`上次结果` 字段: `0` = 成功, `1` = 没找到文件正常, `2-255` = 各种失败。

### 立即触发 schtasks

```cmd
schtasks /run /tn "MyTask"
```

等 10 秒后看 `上次结果`。

### 看 bat 跑日志

```cmd
type %SCRIPT_DIR%\send_daily_report_cron.log
```

bat 用 `1>>"%LOG%" 2>&1` 把 stdout + stderr 写 log 文件。

## 跨项目范式

这 6 坑在以下项目都用过:
- daily-digest 半自动日报 (send_daily_report.bat / verify_and_recover.bat)
- Clove-TestTimer (SETUP_飞书定时器.md)
- Jett 飞轮 (待加)
- 任何用 schtasks + bat + Python 的 Windows 自动化

**Fix 范式**:
1. **Python 路径**: 顶部注释 "升级后改下一行"
2. **bat 编码**: cp936/ANSI, 中文路径走 powershell
3. **ISO timestamp**: powershell, 不用 wmic
4. **循环变量**: `setlocal EnableDelayedExpansion` + `!VAR!`
5. **锁屏**: `/ru SYSTEM /rl highest` (admin)
6. **wsl 弹窗**: 绕 agent agent, schtasks 直调 bat
