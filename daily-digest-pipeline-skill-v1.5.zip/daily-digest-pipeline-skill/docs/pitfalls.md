# 常见坑案例库 (Pitfall Cookbook)

> 8 个真实踩过的坑, 附复现条件 + workaround。

## 坑 1: GitHub README 抓到 UI chrome

**复现**:
```bash
$ markitdown https://github.com/andrewyng/aisuite -o 01-aisuite.md
$ head -20 01-aisuite.md
# Skip to content
# Navigation Menu
# Toggle navigation
# Sign in
# ...
#  ↑ 全是 GitHub 导航, 没有 README 一行字
```

**根因**: markitdown 对 GitHub 渲染页用通用 HTML→MD, 抓不到动态加载的 README。

**Workaround** (✅ 已用):
```bash
curl -L -H "Accept: application/vnd.github.raw" \
  "https://api.github.com/repos/andrewyng/aisuite/readme" \
  -o 01-aisuite.md
```

**额外坑**: README 里有大量相对路径图片 `[![img](_img/foo.png)]`, 需手工删除 (LLM 不看图):
```bash
sed -i 's/!\[[^]]*\]([^)]*)/!/g' 01-aisuite.md
```

---

## 坑 2: 量子位 403 反爬

**复现**:
```bash
$ markitdown https://www.qbitai.com/2026/06/436148.html -o 09.md
403 Forbidden / empty body
```

**根因**: qbitai 用了 Cloudflare, markitdown 默认 User-Agent 被识别为爬虫。

**Workaround** (✅ 已用):
```bash
curl -L \
  -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36" \
  "https://www.qbitai.com/2026/06/436148.html" \
  -o tmp.html
markitdown tmp.html -o 09.md
rm tmp.html
```

**额外坑**: `m.qbitai.com` (移动版) 会 timeout, 用 `www.qbitai.com` 桌面版。

---

## 坑 3: LLM 422 Unprocessable Entity (body 过长)

**复现**:
```python
body = open('qbitai-article.md').read()  # 12000 字符
prompt = f"总结:\n{body}\n输出: ..."
content = chat(messages=[{"role": "user", "content": prompt}], max_tokens=1500)
# 422 Unprocessable Entity
```

**根因**: provider 对单条 message 长度有限 (一般 16K token, 中英文 token 比例 1:1.5)。

**Workaround** (✅ summarize_mds._strip_md_noise + 3 段降级):
1. 去掉 nav: `re.sub(r'^\s*[*\-]\s*\[', '', line)` 跳过连续 `* [首页]` 类导航
2. 截 body 6000 字符
3. 失败 → 4000 → 2500 字符重试

```python
def _call_llm(title, src, raw, body_limit):
    body = _strip_md_noise(raw)[:body_limit]
    return json.loads(chat(...))

# 3 段降级链: 6000 → 4000 → 2500
parsed = _call_llm(t, s, r, 6000) or _call_llm(t, s, r, 4000) or _call_llm(t, s, r, 2500)
```

---

## 坑 4: LLM JSONDecodeError (think 块 / markdown 围栏)

**复现**:
```python
content = chat(...)
# "<think>用户让我总结...</think>\n```json\n{...}\n```"
json.loads(content)
# JSONDecodeError: Expecting value
```

**根因**: MiniMax M3 是 reasoning 模型, 输出含 `<think>` 块; 部分模型还包 ```json 围栏。

**Workaround** (✅ summarize_mds):
```python
content = re.sub(r"<think>.*?</think>", "", content, flags=re.S).strip()
if content.startswith("```"):
    content = content.split("```", 2)[1]
    if content.startswith("json"):
        content = content[4:]
    content = content.strip()
```

---

## 坑 5: Windows GBK console 崩溃

**复现**:
```python
print(f"[summarize] ✅ {json_path}")
# UnicodeEncodeError: 'gbk' codec can't encode character '✅'
```

**根因**: Windows cmd 默认 GBK, 不会自动切到 UTF-8。

**Workaround**:
```python
# 用 ASCII-safe 字符
print(f"[summarize] OK {json_path}")

# 或强制 UTF-8 输出 (Windows Python 3.7+):
import sys
sys.stdout.reconfigure(encoding="utf-8")
```

❌ 不要用 `✅/💡/🔴/🟡/⭐` 等装饰 emoji 在 print 里 (HTML 里可以, console 不行)。

---

## 坑 6: CSS tab panel 空白 (兄弟选择器跨父)

**复现**: 详见 [css-tab-trick.md](css-tab-trick.md)。

**症状**: tab 视觉正常点击, 但 panel 区域**完全空**, 一条横线, 0 报错。

**根因**: `<input>` 嵌在 `.tabbar` 里, `~` 跨不过父元素选不到 `.panels`。

**Workaround**: input 提到 `.tabbar-wrap` 顶层, 跟 `.panels` 同父。

---

## 坑 7: title 提取抓 logo / 文件列表 / footer

**复现**:
```python
md = open('01-aisuite.md').read()
extract_title(md)
# → "├── LICENSE"   (文件树) 或 "Star History" 或 "From the creator of AutoGen"
```

**根因**: GitHub README 头部 logo/目录树, 尾部 Star History / License / About, 都是 H1/H2。

**Workaround** (✅ summarize_mds._extract_title):
```python
# H1 跳过规则
if len(t) < 5: continue
if "├──" in t or "└──" in t: continue
if "/" in t and "." in t: continue          # 文件路径
if t.lower() in ("aisuite", "readme"): continue

# H2 跳过规则 (黑名单)
SKIP_H2 = {"star history", "license", "contributing", "about", "releases",
           "contributors", "footer", "links", "acknowledgments", "support",
           "贡献者", "许可证", "关于", "致谢", "联系", "项目结构", "目录结构"}
SKIP_H2_PREFIX = ("from the creator of",)
```

---

## 坑 8: LLM key 误填 MiniMax.chat SSL 错

**复现**:
```
LLM_API_BASE=https://api.MiniMax.chat
# ssl.SSLCertVerificationError: [SSL: CERTIFICATE_VERIFY_FAILED]
```

**根因**: `api.MiniMax.chat` 是 MiniMax 国内站点 (Cloudflare), SSL 证书对 Python `urllib` 不友好。

**Workaround** (✅ 已用):
```bash
# 正确端点:
LLM_API_BASE=https://api.minimaxi.com/v1
# MiniMax M3
```

---

## 🎯 排查清单

每次出问题时按这个顺序:

1. **HTTP 4xx/5xx** → 检查 User-Agent / API key / 端点
2. **LLM 422** → body 太长, 截短 + 3 段降级
3. **LLM JSON 解析失败** → 去 think 块 / 去 markdown 围栏
4. **HTML 空白** → 检查 input 与 .panels 是否同父
5. **title 错** → 看是不是 logo / footer H1
6. **Windows console 挂** → ASCII-safe 字符
7. **fallback 标记** → 是 LLM 失败, 看 stderr WARN 行
