# run_daily.py + install_cron.bat · 5 步一键编排 + 任务计划

> v1.4 一键跑 5 步 pipeline + Windows 任务计划注册, 同事拿过去改个路径就能跑。

## run_daily.py · 5 步一键编排

```bash
cd scripts/
python run_daily.py 2026-07-03
# 等价于 5 个步骤全跑 + publish 团队目录
```

**5 步**:
1. `agent.py` → `digests/{date}-daily.md` (含跨日去重)
2. `markitdown_automate.py` → `digests/{date} md.材料/*.md` + `manifest.json`
3. `summarize_mds.py` → `digests/{date}-summaries.json` (12 条 LLM 总结)
4. `report_html_v04.py` → `digests/{date}-daily-v04.html` (单文件 HTML, TOP 4)
5. `_publish_to_team` → `半自动日报更新/科技日报V1.0-{date}/` (新命名规范)

**补跑** (`--catchup`):
```bash
python run_daily.py --catchup
# 补跑过去 7 天 (按需)
```

**不 publish** (debug 用):
```bash
python run_daily.py 2026-07-03 --no-publish
# 只在 digests/ 留中间产物, 不 cp 到团队目录
```

## 团队产物新命名规范 (6-22 起)

```
半自动日报更新/科技日报V1.0-2026-7-3/
├── 科技日报V1.0-2026-7-3.html       ← 主产物
├── 科技日报V1.0-2026-7-3.json       ← LLM 总结
└── 科技日报V1.0-2026-7-3 md.材料/   ← 12+ 篇原文
    ├── 01-xxx.md
    ├── manifest.json
    └── ...
```

**月日无前导零** (跟用户原话示例一致: `2026-7-3` 不是 `2026-07-03`)。

## run_daily.bat · Windows 一键跑

```cmd
cd scripts
run_daily.bat 2026-07-03
```

**做了什么**:
- 切到脚本所在目录 (`cd /d "%~dp0"`)
- 读 .env (没有用默认 MiniMax M3)
- 校验 LLM_API_KEY
- 调 `python run_daily.py %*`
- 失败非 0 rc 报警

## install_cron.bat · schtasks 注册

```cmd
REM 需要管理员权限 (失败改用 /ru SYSTEM /rl highest)
cd scripts
install_cron.bat
REM 注册任务 "DailyDigestAgent", 每天 08:00 触发 run_daily.bat
```

**做了什么** (`install_cron.bat`):
```cmd
schtasks /Delete /TN "DailyDigestAgent" /F >nul 2>&1   REM 先删旧
schtasks /Create ^
  /TN "DailyDigestAgent" ^
  /TR "\"%BAT_FILE%\"" ^
  /SC DAILY ^
  /ST 08:00 ^
  /RL HIGHEST
```

**Why 08:00**: 早于 09:50 的运营 cron, 留 1h50min 缓冲 (实际 12+ 篇 LLM 总结 ~10 分钟)。

## Linux/WSL 替代 (crontab.txt)

```bash
# 编辑 crontab
crontab -e

# 加一行 (北京时间 08:00 = UTC 00:00)
0 0 * * * cd ./daily-digest-agent && LLM_API_KEY=sk-xxx LLM_API_BASE=https://api.minimaxi.com/v1 LLM_MODEL=MiniMax-M3 .venv/bin/python run_daily.py >> logs/run_daily.log 2>&1
```

模板在 `scripts/crontab.txt` 注释里。

## 3 段时间窗 (整体)

```
08:00  DailyDigestAgent  (schtasks)  跑 run_daily.py
                                   → digests/ + 半自动日报更新/
09:50  (Clove 跑日报的备份 cron, 防止 08:00 失败)
10:10  投递 agent-DailyReportSend          飞书 DM + Bitable + verify
10:40  投递 agent-DailyReportVerify        兜底 (verify_and_recover.bat)
```

**Why 双 cron**: 08:00 跑失败的话, 09:50 备份 cron 兜底, 10:10 飞书 + Bitable 自动 re-send。

## 已知边界

- **08:00 cron 锁屏不跑**: 默认"只使用交互方式" → 锁屏不触发。Fix: 管理员 `schtasks /create /ru SYSTEM /rl highest`。
- **08:00 cron + LLM 慢响应**: MiniMax M3 长 prompt 慢, 12 篇实测 ~5-10 分钟, timeout 留 30min buffer。
- **markitdown 失败不阻塞**: 单篇 FAIL 不影响其他篇, summarize 走 fallback "见原文"。
- **state.pushed 跨日去重**: 重跑当天 = 必清 state.pushed (否则被 dedupe 过滤掉大部分 URL)。

## 验证

```bash
# 1. 跑通
python run_daily.py 2026-07-03
# 期望输出: 5 步全 OK + 半自动日报更新/科技日报V1.0-2026-7-3/ 3 文件 + md.材料/

# 2. 看 HTML
ls -la digests/2026-07-03-daily-v04.html
# 期望: 50-55 KB

# 3. 看 Bitable 同步
python verify_bitable_sync.py 2026-07-03
# 期望: rc=0, [verify] OK record_id=...
```
