# 飞书 Bitable 同步 + 硬验证 + 10:40 兜底

> 把日报 HTML 同步到飞书多维表格 "科技日报-每日更新", 命名规范化, 双 verify 嵌套防漏。

## 设计 (2026-06-24 用户约定, 2026-07-02 加固)

### 1. 规范化命名 (硬约束)

不论磁盘文件叫 `科技日报V1.0-2026-6-24.html` / `daily-V1.1.html` / `科技日报 V1.2.html` 等等, Bitable 的 `日报名` + 飞书云盘附件名一律:

```
科技日报 YYYY-MM-DD.html
```

**Why**: 历史命名混乱, V 号还会涨, 规范化"日报名"让搜索 / 索引稳定。

### 2. Bitable 字段

```
app_token  = <your_bitable_app_token>     # 配在 .env FEISHU_BITABLE_APP_TOKEN
table_id   = <your_bitable_table_id>      # 配在 .env FEISHU_BITABLE_TABLE_ID
日报日期    (Text)         - "2026-07-03" (单 key 去重)
日报名      (Text)         - "科技日报 2026-07-03"
产出类型    (MultiSelect)  - 固定 ["Html"]
产出        (Attachment)   - drive 媒体资源 (upload_v1/medias/upload_all)
```

去重策略: 按 "日报日期" 单 key 命中 → skip (规范名一致) 或 update (规范名不一致)。**不靠文件名去重**。

### 3. 3 段时间窗 (实测稳定 6-30 → 7-3, 4 天全 rc=0)

```
09:50  Clove 跑 run_daily.py         → 半自动日报更新/科技日报V1.0-2026-7-3/
10:10  send_daily_report.bat (Mode 2) → 飞书 DM 收件
       └ sync_to_bitable.py           → Bitable 同步 (create / update)
       └ verify_bitable_sync.py       → 硬验证 (rc=0)
10:40  verify_and_recover.bat         → 兜底 (缺/不规范 → 自动 re-send + 再 verify)
```

## 4 个脚本职责

| 脚本 | 职责 |
|---|---|
| `sync_to_bitable.py` | 解析 date + version → 规范化命名 → upload drive media → Bitable create/update |
| `verify_bitable_sync.py` | 4 状态码 (0=OK / 1=MISSING / 2=MISMATCH / 3=API_ERROR) |
| `verify_and_recover.bat` | 10:40 兜底, 双 verify 嵌套, 失败 re-send |
| `_send_daily_scan.ps1` | 10:10 入口, 扫今天目录 → 串 3 个 py |

## verify_bitable_sync.py 4 状态码 (硬约定)

```python
def main():
    record, err = find_record(token, target_date)
    if err:   return 3   # API_ERROR
    if not record: return 1   # MISSING

    if name_field != expected_name:   return 2   # MISMATCH
    if attach[0].name != expected_file: return 2   # MISMATCH

    return 0   # OK
```

bat 调度靠这个 rc:
```cmd
%HERMES_PY% -u "%SCRIPTS%\verify_bitable_sync.py"
if %RC% EQU 0 (echo OK) else (call "%SCRIPTS%\send_daily_report.bat")
```

## 双 verify 嵌套 (7-2 加固)

**Why**: 10:10 一次 + 10:40 兜底, 双 verify 嵌套, 实测 7-1/7-2/7-3 全 `rc=0` 没出过事。

**send_daily_report.bat 末尾** (10:10):
```cmd
python send_daily_report.py %HTML%
python sync_to_bitable.py %HTML%
python verify_bitable_sync.py    # 1st verify
```

**verify_and_recover.bat** (10:40):
```cmd
python verify_bitable_sync.py    # 2nd verify
if not %RC% EQU 0 (
  call "%SCRIPTS%\send_daily_report.bat"   # re-send
  python verify_bitable_sync.py         # 3rd verify (兜底)
)
```

## 飞书凭证

```yaml
# ~/.daily-digest/config.yaml
platforms:
  feishu:
    extra:
      app_id: cli_xxxx
      app_secret: xxxx
```

DM `chat_id = <your_dm_chat_id>` 配在 .env `FEISHU_DM_CHAT_ID`。

## 用法

```cmd
REM 1. 同步 (规范化命名 + create/update Bitable)
python sync_to_bitable.py "C:\path\daily.html" --dry-run

REM 2. 硬验证
python verify_bitable_sync.py 2026-07-03

REM 3. 兜底 (10:40 cron)
verify_and_recover.bat
```

## 踩过的坑 (跨项目通用, 详细见 [[windows-schtasks-bat-pitfalls]])

- **Python 路径版本敏感** (0.15.2 → 0.15.3 要改 bat)
- **bat GBK 编码** (cp936/ANSI, 中文路径用 powershell 算)
- **ISO timestamp 用 powershell** (wmic 11 已废)
- **schtasks 锁屏不跑** (需 /ru SYSTEM)
- **wsl.exe 弹窗** (绕过 agent agent shell, schtasks 直调 bat)
- **飞书 file_type 必须是 stream** (HTML 不能用 html)
- **list_message 时间戳必须毫秒** (字符串返 230001)

## 验证 log (2026-07-03)

```
=== 2026-07-03 10:10:02 bat start ===
[scan] dir=科技日报V1.0-2026-7-3  file=科技日报V1.0-2026-7-3.html
[creds] app_id=<elided>...  chat_id=<elided>
[upload] 科技日报 2026-07-03.html (51983 bytes) type=stream
[upload] OK file_key=<elided>
[send] OK message_id=<elided>
[sync] bitable...
[create] OK record_id=<elided>
[verify] OK record_id=<elided> name='科技日报 2026-07-03' size=51983
=== 2026-07-03 10:10:44 bat end rc=0 ===

=== 2026-07-03 10:40:02 10:40 verify-and-recover start ===
[verify] target_date=2026-07-03
[verify] OK record_id=recvogVAKuqqrq
=== 2026-07-03 10:40:02 10:40 verify OK (already in Bitable
```

6-30 → 7-3 4 天, bat end 全 `rc=0`, 10:40 全 OK 没触发 re-send。
