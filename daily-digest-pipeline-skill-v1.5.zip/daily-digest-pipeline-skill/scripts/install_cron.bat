@echo off
REM install_cron.bat · 注册 daily-digest-agent 到 Windows 任务计划程序
REM 用法: 双击运行 (需要管理员权限)
REM 默认: 每天 08:00 (北京时间) 触发, 失败后 30 分钟重试一次

setlocal EnableDelayedExpansion

set "TASK_NAME=DailyDigestAgent"
set "SCRIPT_DIR=%~dp0"
set "BAT_FILE=%SCRIPT_DIR%run_daily.bat"

echo ============================================
echo  注册 daily-digest-agent 到 Windows 任务计划
echo ============================================
echo  任务名: %TASK_NAME%
echo  触发:   每天 08:00
echo  脚本:   %BAT_FILE%
echo ============================================
echo.

REM ── 先删旧的 (避免重复) ──
schtasks /Delete /TN "%TASK_NAME%" /F >nul 2>&1

REM ── 注册新任务 ──
REM /SC DAILY = 每天, /ST 08:00 = 8 点, /RL HIGHEST = 最高权限
schtasks /Create ^
  /TN "%TASK_NAME%" ^
  /TR "\"%BAT_FILE%\"" ^
  /SC DAILY ^
  /ST 08:00 ^
  /RL HIGHEST ^
  /F

if %ERRORLEVEL%==0 (
  echo.
  echo ✅ 注册成功!
  echo.
  echo 验证: schtasks /Query /TN "%TASK_NAME%" /V /FO LIST
  echo 手动跑: 双击 run_daily.bat
  echo 补跑昨天: run_daily.bat 2026-06-16
  echo 卸装:    schtasks /Delete /TN "%TASK_NAME%" /F
) else (
  echo.
  echo ❌ 注册失败, 请以管理员身份运行此脚本
  exit /b 1
)

endlocal
