#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""llm_client.py · v0.3 · MiniMax M3 (OpenAI 兼容) 客户端

.env 必填:
  LLM_API_KEY=sk-...             # MiniMax 控制台拿
  LLM_API_BASE=https://api.minimaxi.com/v1   # 默认 MiniMax, 可换 OpenAI/DeepSeek
  LLM_MODEL=MiniMax-M3            # 或 gpt-4o-mini / deepseek-chat

支持: MiniMax M3 / OpenAI / DeepSeek / Moonshot / 任何 OpenAI 兼容端点
"""
from __future__ import annotations
import json, os, re, sys
from pathlib import Path
from typing import Any
import urllib.request
import urllib.error

ROOT = Path(__file__).resolve().parent


def _load_env() -> dict:
    """简易 .env loader (不依赖 python-dotenv)."""
    env_path = ROOT / ".env"
    env = {}
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    # 兼容系统 env (覆盖 .env)
    for k in ("LLM_API_KEY", "LLM_API_BASE", "LLM_MODEL"):
        if k in os.environ:
            env[k] = os.environ[k]
    return env


def is_configured() -> bool:
    return bool(_load_env().get("LLM_API_KEY"))


def chat(messages: list[dict], model: str | None = None, temperature: float = 0.3, max_tokens: int = 500, timeout: float = 60.0) -> str:
    """单轮 chat completion, 返回 content 字符串. 出错抛 RuntimeError.

    timeout (秒): 单次 HTTP 调用超时 (默认 60s), 防 MiniMax M3 长 prompt 慢响应 15s+ 容易超时
    """
    env = _load_env()
    api_key = env.get("LLM_API_KEY")
    base_url = env.get("LLM_API_BASE", "https://api.minimaxi.com/v1").rstrip("/")
    model = model or env.get("LLM_MODEL", "MiniMax-M3")

    if not api_key:
        raise RuntimeError("LLM_API_KEY 未配置, 在 .env 填上")

    url = f"{base_url}/chat/completions"
    body = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as e:
        raise RuntimeError(f"LLM 调用失败: {type(e).__name__}: {e}") from e

    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError) as e:
        raise RuntimeError(f"LLM 响应格式异常: {data}") from e


# ── per-item 评分 prompt ──

PER_ITEM_PROMPT = """你是数据分析小组的科技/AI 内容策展人。给下面这条信息打分并生成中文摘要。

【标题】{title}
【来源】{source}
【摘要】{summary}

请严格按 JSON 输出 (不要 markdown 围栏, 不要解释):
{{
  "star": <1-5 整数, 5 最高>,
  "why_read": "<1 句话中文, 告诉读者为什么值得读 (≤30 字)>",
  "decision_tag": "<Decision-changing | Actionable | Useful later | Noise 之一>",
  "key_takeaway": "<1 句话中文, 提炼这条最关键的事实/洞察 (≤40 字)>"
}}

判定标准 (decision_tag):
- Decision-changing: 改变看法的 (新模型发布/新范式/新公司动态)
- Actionable: 能立刻动手的 (新工具/教程/prompt/workflow)
- Useful later: 值得收藏的 (深度分析/系统综述/趋势报告)
- Noise: 没营养的 (重复信息/标题党/低质内容)

star 参考: 5=必读, 4=值得读, 3=可看, 2=扫一眼, 1=跳过。
"""


def score_item(item: dict, source_name: str) -> dict:
    """对单条 item 调用 LLM 生成 4 字段, 合并到原 item. 失败时返回兜底 (含原 title/url)."""
    fallback = {
        **item,  # ← 关键: 保留原始 title/url
        "star": 3,
        "why_read": "值得一看",
        "decision_tag": "Useful later",
        "key_takeaway": (item.get("summary") or item.get("title", ""))[:60],
        "llm_failed": True,
    }
    if not is_configured():
        fallback["llm_failed"] = "no_key"
        return fallback
    try:
        prompt = PER_ITEM_PROMPT.format(
            title=item.get("title", "?"),
            source=source_name,
            summary=(item.get("summary") or item.get("title", ""))[:400],
        )
        content = chat(
            messages=[
                {"role": "system", "content": "你是严谨的中文 AI/科技 内容策展人, 输出严格 JSON。"},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.2,
            max_tokens=1500,  # MiniMax-M3 是 reasoning 模型, 需要留给 <think> 块
        )
        # 容忍 <think> 块 (MiniMax M3 是 reasoning 模型, 会先输出思考)
        content = re.sub(r"<think>.*?</think>", "", content, flags=re.S).strip()
        # 容忍 markdown 围栏
        content = content.strip()
        if content.startswith("```"):
            content = content.split("```", 2)[1]
            if content.startswith("json"):
                content = content[4:]
            content = content.strip()
        parsed = json.loads(content)
        star = int(parsed.get("star", 3))
        star = max(1, min(5, star))
        return {
            **item,  # ← 关键: 保留原始 title/url/summary
            "star": star,
            "why_read": str(parsed.get("why_read", ""))[:80],
            "decision_tag": str(parsed.get("decision_tag", "Useful later")),
            "key_takeaway": str(parsed.get("key_takeaway", ""))[:100],
        }
    except Exception as e:
        print(f"[llm] WARN item fail: {item.get('title','?')[:30]}... -> {type(e).__name__}: {e}", file=sys.stderr)
        return fallback


def score_batch(items: list[dict], source_name: str, max_workers: int = 4) -> list[dict]:
    """批量评分. 简单串行 + 进度打印 (并发留给未来优化)."""
    results = []
    n = len(items)
    print(f"[llm] 评分 {source_name}: {n} 条")
    for i, item in enumerate(items, 1):
        # score_item 内部已返回 {**item, **scored_fields}, 这里不要再 spread 否则会覆盖 title/url
        scored = score_item(item, source_name)
        results.append(scored)
        print(f"[llm]   [{i}/{n}] {scored['star']}★ {scored['decision_tag']:<18} {item.get('title','')[:40]}")
    return results


if __name__ == "__main__":
    # 自测: python llm_client.py
    if not is_configured():
        print("[llm] WARN LLM_API_KEY not configured (fill in .env)")
        sys.exit(1)
    sample = {"title": "Claude 4 发布, 新增 computer use", "summary": "Anthropic 发布 Claude 4, 支持屏幕控制, SWE-bench 80%+"}
    out = score_item(sample, "test")
    print(json.dumps(out, ensure_ascii=False, indent=2))
