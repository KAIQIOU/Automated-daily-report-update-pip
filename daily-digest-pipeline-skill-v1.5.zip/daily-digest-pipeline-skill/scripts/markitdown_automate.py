#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""markitdown_automate.py · 把 digests/{date}-daily.md 里的 URL 自动转 md

输入:  digests/{date}-daily.md  (agent.py 输出)
输出:
  - {md_dir}/{NN}-{slug}.md    ← markitdown 转好的 md
  - {md_dir}/manifest.json     ← {file: {theme, src_name, url, title_guess}} 给 summarize_mds.py 用

theme 按 src_name 粗略推断 (跟 v0.4 的 9 源 → 3 主题映射一致), 后续可微调.

用法:  python markitdown_automate.py [date] [daily_md] [md_dir]
"""
from __future__ import annotations
import json, re, subprocess, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
DIGESTS = ROOT / "digests"

# 按 src_name 关键词粗略推断 3 主题 (与 v0.4 06-17 那 12 篇归类一致)
SRC_THEME_KEYS = [
    ("qbitai",    "行业趋势与战略 (视野与决策)"),
    ("36kr",      "行业趋势与战略 (视野与决策)"),
    ("量子位",    "行业趋势与战略 (视野与决策)"),
    ("github",    "AI 工具与 Agent (能立刻动手)"),
    ("hacker",    "AI 工具与 Agent (能立刻动手)"),
    ("hn",        "AI 工具与 Agent (能立刻动手)"),
    ("simon",     "AI 工具与 Agent (能立刻动手)"),
    ("latent",    "AI 工具与 Agent (能立刻动手)"),
    ("r/ai",      "AI 工具与 Agent (能立刻动手)"),
    ("juejin",    "数据工程与 AI 工程实践"),
    ("掘金",      "数据工程与 AI 工程实践"),
    ("v2ex",      "数据工程与 AI 工程实践"),
    ("anthropic", "数据工程与 AI 工程实践"),
    ("claude",    "数据工程与 AI 工程实践"),
]
DEFAULT_THEME = "数据工程与 AI 工程实践"


def _infer_theme(src_name: str) -> str:
    s = src_name.lower()
    for k, v in SRC_THEME_KEYS:
        if k in s:
            return v
    return DEFAULT_THEME


def _slug(url: str) -> str:
    """从 URL 提取人读 slug."""
    # GitHub: github.com/user/repo → user-repo
    m = re.match(r"https?://github\.com/([^/]+)/([^/?#]+?)(?:\.git)?/?$", url)
    if m: return f"{m.group(1)}-{m.group(2)}"
    # 量子位: qbitai.com/yyyy/mm/12345.html → qbitai-12345
    m = re.match(r"https?://(?:www\.)?qbitai\.com/\d{4}/\d{2}/(\d+)\.html", url)
    if m: return f"qbitai-{m.group(1)}"
    # 36kr: 36kr.com/p/12345 → 36kr-12345
    m = re.match(r"https?://36kr\.com/p/(\d+)", url)
    if m: return f"36kr-{m.group(1)}"
    # 掘金: juejin.cn/post/12345 → juejin-12345
    m = re.match(r"https?://juejin\.cn/post/(\d+)", url)
    if m: return f"juejin-{m.group(1)}"
    # Anthropic: claude.com/blog/slug → claude-slug
    m = re.match(r"https?://(?:www\.)?claude\.com/blog/([^?#/]+)", url)
    if m: return f"claude-{m.group(1).replace('/','-')[:40]}"
    # Latent Space: latent.space/p/slug → latent-slug
    m = re.match(r"https?://(?:www\.)?latent\.space/p/([^?#/]+)", url)
    if m: return f"latent-{m.group(1)[:40]}"
    # Simon Willison: simonwillison.net/yyyy/Mon/dd/slug/ → simon-slug
    m = re.match(r"https?://simonwillison\.net/\d{4}/[A-Z][a-z]{2}/\d{1,2}/([^/#?]+)", url)
    if m: return f"simon-{m.group(1)}"
    # V2EX: v2ex.com/t/12345 → v2ex-12345
    m = re.match(r"https?://(?:www\.)?v2ex\.com/t/(\d+)", url)
    if m: return f"v2ex-{m.group(1)}"
    # HN: news.ycombinator.com/item?id=12345 → hn-12345
    m = re.match(r"https?://news\.ycombinator\.com/item\?id=(\d+)", url)
    if m: return f"hn-{m.group(1)}"
    # Reddit: reddit.com/r/xxx/comments/... → reddit-slug
    m = re.match(r"https?://(?:www\.)?reddit\.com/r/([^/]+)/comments/([^/]+)", url)
    if m: return f"reddit-{m.group(1)}-{m.group(2)[:8]}"
    # fallback: 取 path 最后一段
    tail = url.split("//", 1)[-1].split("?")[0].rstrip("/").split("/")[-1]
    return re.sub(r"[^a-zA-Z0-9-]", "-", tail)[:50] or "item"


def _parse_daily_md(md_text: str) -> list[dict]:
    """解析 digests/{date}-daily.md → list[{src_name, title, url}]"""
    items = []
    cur_src = ""
    for line in md_text.splitlines():
        m = re.match(r"^##\s+\d+\.\s+(.+)$", line.strip())
        if m:
            cur_src = m.group(1).strip()
            continue
        m = re.match(r"^\s*-\s+\[([^\]]+)\]\(([^)]+)\)", line)
        if m and cur_src:
            items.append({"src_name": cur_src, "title": m.group(1).strip(), "url": m.group(2).strip()})
    return items


def _http_get_no_proxy(url: str, timeout: int = 30, extra_headers: dict | None = None, retries: int = 2) -> bytes | None:
    """Python urllib 直连 (禁代理) + 浏览器 UA. 解决 curl 走 WinHTTP 代理失败问题.

    返回 bytes (响应体) 或 None (失败). 内置 2 次重试, 应对 hn/hnrss.org 慢响应.
    """
    import time as _t
    import urllib.request as _ur
    # 每次都重置 getproxies, 防 agent.py 那边没改成功
    _ur.getproxies = lambda: {}
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }
    if extra_headers:
        headers.update(extra_headers)
    last_err = None
    for attempt in range(retries + 1):
        try:
            req = _ur.Request(url, headers=headers)
            with _ur.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last_err = e
            if attempt < retries:
                _t.sleep(1.5 * (attempt + 1))  # 1.5s / 3s 退避
                continue
    print(f"[markitdown_auto] http_get {url[:50]}: {type(last_err).__name__}: {last_err}", file=sys.stderr)
    return None


def _markitdown_one(url: str, out_path: Path) -> bool:
    """调 markitdown CLI 转一个 URL 到 md 文件. 失败返回 False.

    反爬处理: 中文站 (qbitai/36kr/juejin) + 通用 (v2ex/hn/simon) 全走 Python urllib 拿 HTML 再 markitdown,
    避开 curl 走 WinHTTP 系统代理 (curl exit 35 SSL 错).
    """
    # 反爬站点列表: 强制走 Python urllib 拿 HTML 再 markitdown (不走 curl, 不走 markitdown URL 直转)
    BYPASS_MARKITDOWN_FETCH = (
        "qbitai.com", "36kr.com", "juejin.cn",
        "v2ex.com", "simonwillison.net", "latent.space",
        "news.ycombinator.com", "reddit.com",
    )
    needs_urllib = any(d in url for d in BYPASS_MARKITDOWN_FETCH)

    try:
        # ── GitHub README: 走 api.github.com raw (markitdown 抓 GitHub UI 是 chrome) ──
        m = re.match(r"https?://github\.com/([^/]+)/([^/?#]+?)(?:\.git)?/?$", url)
        if m:
            user, repo = m.group(1), m.group(2)
            data = _http_get_no_proxy(
                f"https://api.github.com/repos/{user}/{repo}/readme",
                extra_headers={"Accept": "application/vnd.github.raw"},
            )
            if data and data.strip() and b"<!DOCTYPE" not in data[:200]:
                out_path.write_text(data.decode("utf-8", errors="ignore"), encoding="utf-8")
                return True
            return False

        # ── 反爬站: Python urllib 拿 HTML → 落临时文件 → markitdown 转 md ──
        if needs_urllib:
            data = _http_get_no_proxy(url)
            if not data or len(data) < 1000:
                return False
            tmp = out_path.parent / f"_tmp_{out_path.stem}.html"
            tmp.write_bytes(data)
            try:
                r = subprocess.run(
                    ["markitdown", str(tmp), "-o", str(out_path)],
                    capture_output=True, encoding="utf-8", errors="ignore", timeout=60,
                )
                ok = out_path.exists() and out_path.stat().st_size > 500
                if not ok:
                    print(f"[markitdown_auto] FAIL 转 md {out_path.name}: size={out_path.stat().st_size if out_path.exists() else 0}, stderr={r.stderr[:200] if r.stderr else ''}", file=sys.stderr)
                return ok
            finally:
                tmp.unlink(missing_ok=True)

        # ── 默认: 直接 markitdown URL 转 (GitHub 之外没反爬的站) ──
        r = subprocess.run(
            ["markitdown", url, "-o", str(out_path)],
            capture_output=True, encoding="utf-8", errors="ignore", timeout=60,
        )
        return out_path.exists() and out_path.stat().st_size > 200
    except Exception as e:
        print(f"[markitdown_auto] WARN {url[:60]}: {type(e).__name__}: {e}", file=sys.stderr)
        return False


def run(date_str: str, daily_md: Path | None = None, out_dir: Path | None = None) -> Path:
    # 空字符串 / "" 当 None 走默认值 (Path("") == Path("."), 不能误判)
    daily_md = daily_md if (daily_md and str(daily_md) not in (".", "")) else None
    out_dir  = out_dir  if (out_dir  and str(out_dir)  not in (".", "")) else None
    daily_md = daily_md or (DIGESTS / f"{date_str}-daily.md")
    out_dir  = out_dir  or (DIGESTS / f"{date_str} md.材料")
    if not daily_md.exists():
        raise FileNotFoundError(f"未找到 {daily_md}, 先跑 agent.py")

    out_dir.mkdir(parents=True, exist_ok=True)
    # 清空旧的 *.md (防上次重跑残留 → manifest 不覆盖 → 走 THEME_MAP fallback → "未分类")
    # 不删 manifest.json, 下面会重写
    old_md = list(out_dir.glob("*.md"))
    for p in old_md:
        try: p.unlink()
        except OSError: pass
    if old_md:
        print(f"[markitdown_auto] 清空旧 md × {len(old_md)} (防 manifest fallback)")
    items = _parse_daily_md(daily_md.read_text(encoding="utf-8"))
    print(f"[markitdown_auto] 解析 {len(items)} 个 URL → markitdown (out={out_dir})")

    manifest = {}
    ok_cnt = 0
    for i, it in enumerate(items, 1):
        slug = _slug(it["url"])
        out_path = out_dir / f"{i:02d}-{slug}.md"
        ok = _markitdown_one(it["url"], out_path)
        flag = "OK" if ok else "FAIL"
        print(f"  [{i:02d}] {flag:4s} {slug}")
        if ok: ok_cnt += 1
        manifest[out_path.name] = {
            "theme":      _infer_theme(it["src_name"]),
            "src_name":   it["src_name"],
            "url":        it["url"],
            "title_guess": it["title"],
        }

    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[markitdown_auto] OK manifest.json ({ok_cnt}/{len(items)} 成功)")
    return out_dir


if __name__ == "__main__":
    """用法: python markitdown_automate.py [date] [daily_md] [md_dir]
    空字符串当 None (走默认值), 避免 Path("") = Path(".") 报 PermissionError."""
    date = sys.argv[1] if len(sys.argv) > 1 else datetime.now(BJT).strftime("%Y-%m-%d")
    daily = Path(sys.argv[2]) if (len(sys.argv) > 2 and sys.argv[2]) else None
    out   = Path(sys.argv[3]) if (len(sys.argv) > 3 and sys.argv[3]) else None
    sys.exit(0 if run(date, daily, out) else 1)