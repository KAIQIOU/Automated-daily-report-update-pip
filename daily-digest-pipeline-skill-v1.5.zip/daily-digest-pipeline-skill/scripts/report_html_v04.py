#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""report_html_v04.py · v1.2 · 4 tab 切换 + 3 主题每主题 TOP_N 条 + star/why_read/pub_date

设计 (2026-06-17 V1.1 起, 2026-06-18 V1.2: 限制每主题 TOP_N 条):
- 沿用 v0.3 莫兰迪色板
- 4 tab 横向切换: 总览 / 动手 / 提升 / 视野  (无 JS, 纯 CSS radio 兄弟选择器)
- 总览 panel: 3 列 grid 概览卡 (色块 + 主题名 + N 条 + brief)
- 主题 panel: 该主题的 TOP_N 条 item (按 star 降序, 5★→1★; 同分按 pub_date 降序; 再同分保持原序)
- item 字段: 序号 + star + 标题 + src + pub_date + "为什么读" + "这篇讲什么" + "对我们有啥用" + 关键要点 + 末尾溯源

TOP_N_PER_THEME = 4 (2026-06-18 起用户硬约束: 每主题只取 4 条, 总 12 条/天)

输入: digests/{date}-summaries.json  (或 --in 指定)
输出: digests/{date}-daily-v04.html   (或 --out 指定)
HTML 顶部 v{version} 与 footer 路径通过 --version 改写 (默认 "1.1")
"""
from __future__ import annotations
import argparse, json, re, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
DIGEST_DIR = ROOT / "digests"

# ── 每主题最多显示 N 条 (用户硬约束 2026-06-18 起: 每主题 4 条, 总 12 条/天) ──
TOP_N_PER_THEME = 4

# ── 莫兰迪色板 (沿用 v0.3) ──
MORANDI = {
    "bg":       "#F4F1EC",
    "surface":  "#FBF8F3",
    "surface2": "#EDE7DD",
    "ink":      "#2E2A26",
    "mute":     "#7A7268",
    "accent":   "#9C8F7E",
    "a2":       "#A8B5A0",  # 绿 - 动手
    "a3":       "#C4A484",  # 橙黄 - 提升
    "a4":       "#B5A8A3",  # 粉 - 视野
    "a5":       "#8B9DAA",  # 蓝 - 总览标签
}

# 主题名 → (色, 短标签, 短 slug, 1 句话 brief)
THEME_META = {
    "AI 工具与 Agent (能立刻动手)":  (MORANDI["a2"], "动手", "action", "新模型 / Agent 框架 / 立刻能上手的 coding 工具与工作流"),
    "数据工程与 AI 工程实践":         (MORANDI["a3"], "提升", "promote", "RAG / workflow / 数据处理 / prompt 的工程化踩坑与最佳实践"),
    "行业趋势与战略 (视野与决策)":    (MORANDI["a4"], "视野", "vision",  "报告 / 融资 / 监管 / 商业模式 等行业大势与决策信号"),
}

# ── SVG icons (沿用 v0.3) ──
ICON_STAR  = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 16.8l-6.2 4.5 2.4-7.4L2 9.4h7.6z"/></svg>'
ICON_EXT   = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 4h6v6M10 14L20 4M19 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6"/></svg>'
ICON_CHECK = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 12l4 4 10-10"/></svg>'
ICON_QUOTE = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 8h4v8H6zm8 0h4v8h-4z"/></svg>'
ICON_BOLT  = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/></svg>'
ICON_CAL   = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>'
ICON_WHY   = '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.5-2.5 2-2.5 4M12 17h.01"/></svg>'


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _star_html(n: int) -> str:
    """1-5 星, ★ 实心 ☆ 空心. n=0 → 显示 '未评'."""
    n = max(0, min(5, int(n or 0)))
    if n == 0:
        return '<span class="star-row star-empty">未评</span>'
    full = "★" * n
    empty = "☆" * (5 - n)
    return f'<span class="star-row" title="{n}/5">{full}<span class="star-dim">{empty}</span></span>'


def _pub_html(date: str) -> str:
    if not date:
        return '<span class="pub-empty">—</span>'
    return f'<span class="pub-date">{_esc(date)}</span>'


def _clean_fallback_summary(s: str) -> str:
    if not s:
        return s
    m = re.search(r">(.*)", s, re.S)
    if m:
        return m.group(1).strip()[:180]
    s = re.sub(r"^\d{4}-\d{2}-\d{2}\s*\n", "", s)
    s = re.sub(r"^\d+\s*\n", "", s)
    s = re.sub(r"阅读\d+分钟", "", s)
    return s.strip()[:180]


def render_item(idx: int, s: dict, theme_color: str) -> str:
    """单条总结: 序号 + star + 标题 + src + pub_date + 为什么读 + 这篇讲什么 + 对我们有啥用 + 关键要点 + 溯源."""
    title   = s.get("title") or s.get("file", "?")
    src     = s.get("src_name", "")
    url     = s.get("url", "")
    summary = s.get("summary", "")
    value   = s.get("value", "")
    points  = s.get("key_points") or []
    why     = s.get("why_read", "")
    star    = int(s.get("star") or 0)
    pub     = s.get("pub_date", "")
    is_fb   = bool(s.get("llm_failed"))

    if is_fb:
        summary = _clean_fallback_summary(summary)
        value   = "本条 LLM 调用失败, 见原文确认。"
        why     = why or "见原文"
        star    = 0

    points_html = ""
    if points:
        points_html = '<ul class="it-points">' + "".join(
            f'<li>{_esc(p)}</li>' for p in points[:3]
        ) + "</ul>"

    fb_mark = '<span class="fb-mark" title="LLM 失败, 走 fallback">⚠ fallback</span>' if is_fb else ''

    return f"""
<article class="item" style="--theme-c:{theme_color}">
  <div class="it-head">
    <div class="it-idx">{idx:02d}</div>
    <div class="it-main">
      <a class="it-title" href="{_esc(url)}" target="_blank" rel="noopener">{_esc(title)}</a>
      <div class="it-meta">
        <span class="it-src">{_esc(src)}</span>
        {_star_html(star)}
        <span class="it-pub">{ICON_CAL}{_pub_html(pub)}</span>
        {fb_mark}
      </div>
    </div>
  </div>

  {f'<div class="it-section it-why"><div class="it-section-label">{ICON_WHY} 为什么读</div><div class="it-why-body">{_esc(why)}</div></div>' if why else ''}

  <div class="it-section">
    <div class="it-section-label">{ICON_QUOTE} 这篇讲什么</div>
    <div class="it-summary">{_esc(summary)}</div>
  </div>

  <div class="it-section it-value">
    <div class="it-section-label">{ICON_BOLT} 对我们有啥用</div>
    <div class="it-value-body">{_esc(value)}</div>
  </div>

  {f'<div class="it-section"><div class="it-section-label">{ICON_CHECK} 关键要点</div>{points_html}</div>' if points_html else ''}

  <div class="it-foot">
    <a class="it-link" href="{_esc(url)}" target="_blank" rel="noopener">{ICON_EXT} 原文溯源 (供核验)</a>
  </div>
</article>
"""


def render_theme_panel(theme_name: str, items: list[dict], slug: str) -> str:
    color, label, _slug, brief = THEME_META.get(theme_name, (MORANDI["a5"], "?", slug, ""))
    items_html = "".join(render_item(i + 1, s, color) for i, s in enumerate(items))
    return f"""
<section class="panel" id="panel-{slug}">
  <header class="theme-hd" style="--theme-c:{color}">
    <div class="theme-tag" style="background:{color}">{label}</div>
    <h2 class="theme-name">{_esc(theme_name)}</h2>
    <div class="theme-count">{len(items)} 条</div>
  </header>
  <p class="theme-brief">{_esc(brief)}</p>
  <div class="theme-body">
    {items_html}
  </div>
</section>
"""


def render_overview_panel(themes: list[str], by_theme: dict[str, list[dict]], total: int) -> str:
    """总览: 3 列 grid 概览卡, 每卡=色块+主题名+条数+brief+按钮跳到主题 tab."""
    cards = ""
    for t in themes:
        if t not in THEME_META:
            continue
        color, label, slug, brief = THEME_META[t]
        n = len(by_theme.get(t, []))
        # 列前 3 条 mini-list
        mini = ""
        for i, s in enumerate(by_theme.get(t, [])[:3], 1):
            star = int(s.get("star") or 0)
            star_chip = _star_html(star)
            mini += f"""
        <li class="ov-mini">
          <span class="ov-num">{i:02d}</span>
          <span class="ov-title">{_esc(s.get('title', '?')[:28])}</span>
          <span class="ov-star">{star_chip}</span>
        </li>"""
        cards += f"""
<label class="ov-card" for="tab-{slug}" style="--theme-c:{color}">
  <header class="ov-hd">
    <div class="theme-tag" style="background:{color}">{label}</div>
    <div class="ov-count"><b>{n}</b><span> 条</span></div>
  </header>
  <h3 class="ov-name">{_esc(t)}</h3>
  <p class="ov-brief">{_esc(brief)}</p>
  <ul class="ov-mini-list">{mini}
      </ul>
  <div class="ov-cta">查看 {n} 条 →</div>
</label>"""

    return f"""
<section class="panel" id="panel-overview">
  <header class="theme-hd" style="--theme-c:{MORANDI['a5']}">
    <div class="theme-tag" style="background:{MORANDI['a5']}">总览</div>
    <h2 class="theme-name">今日 {total} 条 · 按 3 主题分类</h2>
    <div class="theme-count">点卡片可跳转</div>
  </header>
  <p class="theme-brief">每天的内容按"动手 / 提升 / 视野"3 主题分组, 点上方 tab 或下方卡片切换查看。</p>
  <div class="ov-grid">
    {cards}
  </div>
</section>
"""


CSS = f"""
:root {{
  --bg: {MORANDI['bg']};
  --surface: {MORANDI['surface']};
  --surface2: {MORANDI['surface2']};
  --ink: {MORANDI['ink']};
  --mute: {MORANDI['mute']};
  --accent: {MORANDI['accent']};
  --a5: {MORANDI['a5']};
}}
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{background:var(--bg);color:var(--ink);font:15px/1.65 -apple-system,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif}}
.wrap{{max-width:760px;margin:0 auto;padding:32px 24px 64px}}
.i{{width:14px;height:14px;display:inline-block;vertical-align:-2px;margin-right:4px}}
.eyebrow{{font-size:11px;letter-spacing:1.5px;color:var(--mute);text-transform:uppercase;margin-bottom:8px}}
h1{{font-size:28px;font-weight:600;letter-spacing:-0.5px;margin-bottom:6px}}
.lede{{color:var(--mute);font-size:14px;margin-bottom:24px;line-height:1.7}}

.meta-bar{{display:flex;flex-wrap:wrap;gap:8px;padding:14px 18px;background:var(--surface);border:1px solid var(--surface2);border-radius:10px;margin-bottom:24px}}
.meta-bar .mb{{display:flex;align-items:center;gap:6px;font-size:13px;color:var(--mute)}}
.meta-bar .mb b{{color:var(--ink);font-weight:600}}
.meta-bar .sep{{width:1px;height:14px;background:var(--surface2);margin:0 4px}}

/* ── Tab 切换 (纯 CSS, 无 JS) ── */
/* 关键: input 必须跟 .panels 同父, 否则 ~ 选不到 */
.tabs-root > input{{display:none}}
.tabbar-wrap{{position:sticky;top:0;z-index:50;background:var(--bg);padding:8px 0 0;margin:0 -24px 0;border-bottom:1px solid var(--surface2)}}
.tabbar{{display:flex;gap:0;padding:0 24px;overflow-x:auto}}
.tabbar label{{padding:11px 14px 12px;cursor:pointer;color:var(--mute);font-size:14px;white-space:nowrap;border-bottom:2px solid transparent;transition:color .15s,border-color .15s}}
.tabbar label:hover{{color:var(--ink)}}
#tab-overview:checked ~ .tabbar label[for="tab-overview"],
#tab-action:checked   ~ .tabbar label[for="tab-action"],
#tab-promote:checked  ~ .tabbar label[for="tab-promote"],
#tab-vision:checked   ~ .tabbar label[for="tab-vision"]{{color:var(--ink);font-weight:600;border-bottom-color:var(--a5)}}
#tab-overview:checked ~ .panels #panel-overview,
#tab-action:checked   ~ .panels #panel-action,
#tab-promote:checked  ~ .panels #panel-promote,
#tab-vision:checked   ~ .panels #panel-vision{{display:block}}
.panels .panel{{display:none}}

/* ── 主题卡片 (主题 panel) ── */
.theme-hd{{display:flex;align-items:center;gap:10px;margin-bottom:8px;padding-bottom:10px;border-bottom:1px dashed var(--surface2)}}
.theme-tag{{display:inline-block;padding:3px 10px;border-radius:6px;color:#fff;font-size:11px;font-weight:600;letter-spacing:1px}}
.theme-name{{flex:1;font-size:17px;font-weight:600;color:var(--ink)}}
.theme-count{{font-size:13px;color:var(--mute)}}
.theme-brief{{font-size:13px;color:var(--mute);line-height:1.7;margin-bottom:18px;padding:8px 12px;background:var(--surface);border-radius:8px;border-left:3px solid var(--theme-c, var(--surface2))}}
.theme-body{{display:flex;flex-direction:column;gap:18px}}

/* ── 总览卡片 grid ── */
.ov-grid{{display:grid;grid-template-columns:1fr;gap:14px;margin-top:6px}}
@media(min-width:640px){{.ov-grid{{grid-template-columns:repeat(3,1fr)}}}}
.ov-card{{display:block;background:var(--surface);border:1px solid var(--surface2);border-radius:12px;padding:16px 16px 12px;cursor:pointer;border-left:4px solid var(--theme-c);transition:transform .15s,box-shadow .15s}}
.ov-card:hover{{transform:translateY(-2px);box-shadow:0 4px 12px rgba(46,42,38,0.06)}}
.ov-hd{{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}}
.ov-count b{{font-size:20px;color:var(--ink);font-weight:700}}
.ov-count span{{font-size:12px;color:var(--mute);margin-left:2px}}
.ov-name{{font-size:14px;font-weight:600;color:var(--ink);margin-bottom:6px;line-height:1.4}}
.ov-brief{{font-size:12px;color:var(--mute);line-height:1.65;margin-bottom:10px}}
.ov-mini-list{{list-style:none;padding:0;margin:0 0 10px}}
.ov-mini{{display:flex;align-items:center;gap:6px;padding:4px 0;border-bottom:1px dashed var(--surface2);font-size:12px;color:var(--ink)}}
.ov-mini:last-child{{border-bottom:none}}
.ov-num{{flex:0 0 auto;width:18px;height:18px;border-radius:5px;background:var(--theme-c);color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600}}
.ov-title{{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.ov-star{{flex:0 0 auto;font-size:10px;letter-spacing:1px}}
.ov-cta{{font-size:12px;color:var(--theme-c);font-weight:600;text-align:right;letter-spacing:0.5px}}

/* ── 单条 item ── */
.item{{background:var(--bg);border-radius:10px;padding:16px 18px;border-left:2px solid var(--theme-c)}}
.it-head{{display:flex;gap:12px;align-items:flex-start;margin-bottom:10px}}
.it-idx{{flex:0 0 auto;width:30px;height:30px;border-radius:8px;background:var(--theme-c);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;letter-spacing:0.5px}}
.it-main{{flex:1;min-width:0}}
.it-title{{display:block;font-size:15px;font-weight:600;color:var(--ink);text-decoration:none;line-height:1.5;margin-bottom:4px}}
.it-title:hover{{color:var(--accent);text-decoration:underline}}
.it-meta{{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:12px;color:var(--mute)}}
.it-src{{background:var(--surface);padding:2px 8px;border-radius:5px;border:1px solid var(--surface2);color:var(--ink)}}
.star-row{{color:#C49A4A;font-size:12px;letter-spacing:1px}}
.star-row .star-dim{{color:var(--surface2)}}
.star-row.star-empty{{color:var(--mute);font-size:11px;letter-spacing:0}}
.it-pub{{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--mute);background:var(--surface);padding:1px 7px;border-radius:4px}}
.it-pub .pub-empty{{color:var(--mute)}}
.fb-mark{{font-size:10px;color:#B0786E;background:#F4EAE5;padding:1px 6px;border-radius:4px}}

.it-section{{margin-top:10px}}
.it-section-label{{display:flex;align-items:center;gap:4px;font-size:11px;color:var(--mute);font-weight:600;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px}}
.it-summary,.it-value-body,.it-why-body{{font-size:14px;line-height:1.7;color:var(--ink)}}
.it-value-body{{font-weight:500}}
.it-why-body{{font-style:italic;color:var(--ink);background:var(--surface);padding:6px 10px;border-radius:6px;border-left:2px solid var(--theme-c);font-size:13px}}
.it-points{{list-style:none;padding:0;margin:0}}
.it-points li{{position:relative;padding-left:18px;font-size:13px;line-height:1.7;color:var(--ink);margin-bottom:2px}}
.it-points li::before{{content:"·";position:absolute;left:4px;top:-2px;color:var(--theme-c);font-size:18px;font-weight:700}}

.it-foot{{display:flex;justify-content:flex-end;margin-top:10px;padding-top:8px;border-top:1px dashed var(--surface2)}}
.it-link{{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--mute);text-decoration:none;letter-spacing:0.3px}}
.it-link:hover{{color:var(--accent);text-decoration:underline}}

footer.page-ft{{margin-top:48px;padding-top:20px;border-top:1px solid var(--surface2);font-size:12px;color:var(--mute);text-align:center}}
footer.page-ft .row{{margin-bottom:4px}}
footer.page-ft b{{color:var(--ink);font-weight:500}}

@media print{{
  .wrap{{max-width:none;padding:0}}
  .tabbar-wrap{{position:static}}
  .panels .panel{{display:block !important;page-break-after:always}}
  .theme-card,.panel{{break-inside:avoid;box-shadow:none}}
}}
"""


def build_html(data: dict) -> str:
    date_str = data.get("date", datetime.now(BJT).strftime("%Y-%m-%d"))
    summaries = data.get("summaries", [])
    themes = data.get("themes", [])
    llm = data.get("llm", "OFF")
    version = data.get("version", "0.4")

    by_theme: dict[str, list[dict]] = {t: [] for t in themes}
    for s in summaries:
        t = s.get("theme", "")
        if t in by_theme:
            by_theme[t].append(s)
        else:
            by_theme.setdefault(t, []).append(s)

    # 2026-06-18 V1.2 起: 每主题只留 TOP_N 条 (按 star 降序, 同分按 pub_date 降序, 再同分保持原序)
    def _sort_key(s: dict) -> tuple[int, str, int]:
        star = int(s.get("star") or 0)
        pub = s.get("pub_date", "") or ""
        return (star, pub, 0)
    for t in list(by_theme.keys()):
        # 用 stable 排序: 先按 star desc, 再按 pub_date desc, 用负号 + tuple
        items = by_theme[t]
        items.sort(key=lambda s: (-int(s.get("star") or 0), -(0 if not s.get("pub_date") else 1),
                                  s.get("pub_date", "") or ""))
        by_theme[t] = items[:TOP_N_PER_THEME]

    n_total = len(summaries)
    n_fb = sum(1 for s in summaries if s.get("llm_failed"))
    n_llm = n_total - n_fb

    # 总览
    overview = render_overview_panel(themes, by_theme, n_total)
    # 3 个主题 panel
    theme_panels = "".join(
        render_theme_panel(t, by_theme.get(t, []), THEME_META.get(t, (None, None, "x", ""))[2])
        for t in themes if t in THEME_META and by_theme.get(t)
    )

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>每日信源日报 · v{version} · {date_str}</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">

  <div class="eyebrow">DAILY DIGEST · v{version} · LLM: {llm} · 3 主题分组 + TAB 切换</div>
  <h1>每日信源日报</h1>
  <p class="lede">为数据分析 + AI 应用小组筛选 <b>{n_total}</b> 条近期高质量内容 · 数据截至 {date_str}<br>
  按 <b>{len(themes)}</b> 个主题分类, 每条含 <b>星级 + 留言 + 发布日期 + LLM 总结 + 价值 + 关键要点</b></p>

  <div class="meta-bar">
    <span class="mb"><b>{n_total}</b> 条 / LLM 成功 <b>{n_llm}</b> · fallback <b>{n_fb}</b></span>
    <span class="sep"></span>
    <span class="mb">{len(themes)} 主题 · {date_str}</span>
    <span class="sep"></span>
    <span class="mb">生成于 <b>{datetime.now(BJT):%H:%M} UTC+8</b></span>
  </div>

  <div class="tabbar-wrap tabs-root">
    <input type="radio" name="tab" id="tab-overview" checked>
    <input type="radio" name="tab" id="tab-action">
    <input type="radio" name="tab" id="tab-promote">
    <input type="radio" name="tab" id="tab-vision">
    <nav class="tabbar" role="tablist">
      <label for="tab-overview">总览</label>
      <label for="tab-action">动手</label>
      <label for="tab-promote">提升</label>
      <label for="tab-vision">视野</label>
    </nav>
    <div class="panels">
      {overview}
      {theme_panels}
    </div>
  </div>

  <footer class="page-ft">
    <div class="row">daily-digest-agent v{version} · 3 主题 (动手/提升/视野) · 4 tab 切换 (无 JS) · 每主题 TOP {TOP_N_PER_THEME}</div>
    <div class="row">信源池: <b>9 源 (5 英 + 4 中)</b> · LLM: <b>{llm}</b> · 输出: <b>半自动日报更新/{date_str}-daily-V{version}/</b></div>
    <div class="row">© vibecoding 数据分析小组 · 每条总结基于 markitdown 后的原文 + LLM 总结</div>
  </footer>

</div>
</body>
</html>
"""


def render(date_str: str, in_path: Path | None = None, out_path: Path | None = None) -> Path:
    src = in_path or (DIGEST_DIR / f"{date_str}-summaries.json")
    if not src.exists():
        raise FileNotFoundError(f"未找到 {src}, 先跑 summarize_mds.py")
    data = json.loads(src.read_text(encoding="utf-8"))
    html = build_html(data)
    dst = out_path or (DIGEST_DIR / f"{date_str}-daily-v04.html")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(html, encoding="utf-8")
    print(f"[report_html_v04] OK write {dst} ({dst.stat().st_size} bytes)")
    return dst


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("date", nargs="?", default=None)
    ap.add_argument("--in",      dest="in_path",  default=None, help="输入 summaries json 路径")
    ap.add_argument("--out",     dest="out_path", default=None, help="输出 html 路径")
    ap.add_argument("--version", dest="version",  default="1.1", help="HTML 内显示的版号 (默认 1.1, V1.2 限制每主题 4 条)")
    args = ap.parse_args()
    date = args.date or datetime.now(BJT).strftime("%Y-%m-%d")
    in_p  = Path(args.in_path)  if args.in_path  else None
    out_p = Path(args.out_path) if args.out_path else None
    try:
        # 把 version 注入 data (build_html 用 data["version"])
        from json import loads as _jl
        src = in_p or (DIGEST_DIR / f"{date}-summaries.json")
        data = _jl(src.read_text(encoding="utf-8"))
        data["version"] = args.version
        html = build_html(data)
        dst = out_p or (DIGEST_DIR / f"{date}-daily-v04.html")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(html, encoding="utf-8")
        print(f"[report_html_v04] OK write {dst} ({dst.stat().st_size} bytes, v{args.version}, top={TOP_N_PER_THEME})")
    except FileNotFoundError as e:
        print(f"[report_html_v04] ERR: {e}", file=sys.stderr)
        sys.exit(1)
