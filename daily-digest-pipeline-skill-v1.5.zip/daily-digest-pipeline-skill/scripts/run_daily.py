#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""run_daily.py · v0.4 · 每日信源日报编排 (V1.1 风格: 4 tab 切换 + star/why_read/pub_date)

流程 (v0.4 全自动):
  1. agent.py              → digests/{date}-daily.md
  2. markitdown_automate.py → digests/{date} md.材料/*.md + manifest.json
  3. summarize_mds.py      → digests/{date}-summaries.json (LLM 总结 + star/why_read/pub_date)
  4. report_html_v04.py    → digests/{date}-daily-v04.html (4 tab 切换 + 莫兰迪)
  5. 复制到 <日报>/半自动日报更新/科技日报{version}-{YYYY}-{M}-{D}/  (新命名规范 2026-06-22 起)

用法:
  python run_daily.py                    # 跑当天
  python run_daily.py 2026-06-17         # 跑指定日
  python run_daily.py --catchup          # 补跑过去 7 天 (按需)
"""
from __future__ import annotations
import argparse, shutil, subprocess, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
# 团队产出根: <日报>/半自动日报更新/  (项目根的同级, 自动跟随整个 日报/ 目录搬移)
DAILY_OUTPUT = ROOT.parent / "半自动日报更新"


def fmt_team_basename(date_str: str, version: str = "V1.0") -> str:
    """从 ISO 日期 (2026-06-22) + version (V1.0) 生成团队产物 basename。

    新规范 (2026-06-22 起): 目录 / HTML / summaries / md.材料 都用同一个 basename。
      fmt_team_basename("2026-06-22", "V1.0") -> "科技日报V1.0-2026-6-22"
      月日无前导零 (跟用户原话示例一致)。
    """
    dt = datetime.strptime(date_str, "%Y-%m-%d")
    return f"科技日报{version}-{dt.year}-{dt.month}-{dt.day}"


def _run_script(script: str, *args: str) -> bool:
    cmd = [sys.executable, str(ROOT / script), *args]
    # Windows GBK 控制台不支持 unicode, 用 ASCII-safe 分隔符
    print(f"\n{'='*60}\n[run] {' '.join(cmd)}\n{'='*60}")
    r = subprocess.run(
        cmd,
        cwd=str(ROOT),
        env={**__import__("os").environ},
    )
    return r.returncode == 0


def _publish_to_team(date_str: str, md_dir: Path, version: str = "V1.0") -> Path:
    """复制到 <日报>/半自动日报更新/ 团队目录。

    新命名规范 (2026-06-22 起): 全部用同一 basename 前缀,月日无前导零。
      例 (date_str=2026-06-22, version=V1.0):
        目录     科技日报V1.0-2026-6-22/
        HTML     科技日报V1.0-2026-6-22.html
        summary  科技日报V1.0-2026-6-22.json
        md.材料  科技日报V1.0-2026-6-22 md.材料/
    """
    base = fmt_team_basename(date_str, version)
    out_dir = DAILY_OUTPUT / base
    out_dir.mkdir(parents=True, exist_ok=True)

    html_src       = ROOT / "digests" / f"{date_str}-daily-v04.html"
    summaries_src  = ROOT / "digests" / f"{date_str}-summaries.json"

    html_dst       = out_dir / f"{base}.html"
    summaries_dst  = out_dir / f"{base}.json"
    md_dst_dir     = out_dir / f"{base} md.材料"

    shutil.copy2(html_src, html_dst)
    if summaries_src.exists():
        shutil.copy2(summaries_src, summaries_dst)
    if md_dir.exists():
        if md_dst_dir.exists():
            shutil.rmtree(md_dst_dir)
        shutil.copytree(md_dir, md_dst_dir)

    print(f"\n[publish] OK 团队产物 (新命名规范 {base}):")
    print(f"  dir: {out_dir}")
    print(f"  html:       {html_dst.name}")
    if summaries_dst.exists():
        print(f"  summaries:  {summaries_dst.name}")
    if md_dst_dir.exists():
        print(f"  md.材料:     {md_dst_dir.name} ({sum(1 for _ in md_dst_dir.glob('*.md'))} md)")
    return out_dir


def run_one(date_str: str, publish: bool = True) -> bool:
    md_dir = ROOT / "digests" / f"{date_str} md.材料"
    ok = True
    ok &= _run_script("agent.py", date_str)
    ok &= _run_script("markitdown_automate.py", date_str, "", str(md_dir))
    ok &= _run_script("summarize_mds.py", date_str, str(md_dir), str(ROOT / "digests"))
    ok &= _run_script("report_html_v04.py", date_str)
    if ok and publish:
        _publish_to_team(date_str, md_dir)
    return ok


def main():
    p = argparse.ArgumentParser()
    p.add_argument("date", nargs="?", default=datetime.now(BJT).strftime("%Y-%m-%d"))
    p.add_argument("--catchup", action="store_true", help="补跑过去 7 天")
    p.add_argument("--no-publish", action="store_true")
    args = p.parse_args()

    if args.catchup:
        for i in range(7, 0, -1):
            d = (datetime.now(BJT) - timedelta(days=i)).strftime("%Y-%m-%d")
            run_one(d, publish=not args.no_publish)
    else:
        sys.exit(0 if run_one(args.date, publish=not args.no_publish) else 1)


if __name__ == "__main__":
    main()
