#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dedupe.py · v0.1 · 跨日去重工具

两个用法:
  1. 独立 dry-run: python dedupe.py <date>-daily.md     # 看会删哪些
  2. 集成进 agent.py: from dedupe import dedupe_against_history

去重规则 (三层, 按顺序):
  L1. URL 完全匹配 (normalized)         — 7 天窗口
  L2. 标题模糊匹配 (SequenceMatcher≥0.85) — 7 天窗口
  L3. GitHub Trending 同 repo           — 7 天窗口 (URL 形如 github.com/{u}/{r})

state.json 结构:
  "pushed": [
    {"date": "2026-06-22", "url": "...", "title": "...", "src": "..."},
    ...
  ]
"""
from __future__ import annotations
import json, re, sys
from datetime import datetime, timezone, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from urllib.parse import urlparse, urlunparse, parse_qs

BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
STATE = ROOT / "state.json"
DIGEST_DIR = ROOT / "digests"

WINDOW_DAYS = 7         # 去重窗口
TITLE_SIM_THRESHOLD = 0.85
KEEP_HISTORY_DAYS = 14  # state.json 里 pushed 保留多久


# ── URL normalize ──────────────────────────────────────────────────
_UTM_PARAMS = ("utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "ref", "source")


def normalize_url(url: str) -> str:
    """去 utm_* / trailing slash / 标准化 scheme, 用于去重比较."""
    if not url:
        return ""
    try:
        u = urlparse(url.strip())
    except Exception:
        return url.strip().lower()
    # 去 utm_*
    qs = parse_qs(u.query, keep_blank_values=False)
    qs = {k: v for k, v in qs.items() if k.lower() not in _UTM_PARAMS}
    new_q = "&".join(f"{k}={'&'.join(vs)}" for k, vs in qs.items())
    # 去掉 trailing slash (path 不为 / 时)
    path = u.path.rstrip("/") if u.path != "/" else u.path
    return urlunparse((u.scheme.lower(), u.netloc.lower(), path, u.params, new_q, ""))


# ── GitHub repo 抽取 ──────────────────────────────────────────────
_GH_REPO_RE = re.compile(r"github\.com/([\w.-]+)/([\w.-]+)")


def github_repo(url: str) -> str | None:
    """从 URL 抽 'user/repo', 用于 L3 GitHub Trending 去重."""
    if not url:
        return None
    m = _GH_REPO_RE.search(url)
    if not m:
        return None
    user, repo = m.group(1), m.group(2)
    # 去 .git 后缀
    if repo.endswith(".git"):
        repo = repo[:-4]
    return f"{user.lower()}/{repo.lower()}"


# ── state.json 读写 ────────────────────────────────────────────────
def load_state() -> dict:
    if not STATE.exists():
        return {"sources": {}, "history": [], "pushed": []}
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[dedupe] WARN state.json 解析失败: {e}", file=sys.stderr)
        return {"sources": {}, "history": [], "pushed": []}


def save_state(state: dict) -> None:
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def trim_history(state: dict) -> None:
    """裁剪 pushed 到最近 KEEP_HISTORY_DAYS 天."""
    cutoff = (datetime.now(BJT) - timedelta(days=KEEP_HISTORY_DAYS)).strftime("%Y-%m-%d")
    state["pushed"] = [p for p in state.get("pushed", []) if p.get("date", "") >= cutoff]


def get_history_index(state: dict, days: int = WINDOW_DAYS) -> tuple[set[str], list[tuple[str, str]], dict[str, list[str]]]:
    """构建去重索引: (url_norm 集合, [(url_norm, title)] 列表, {gh_repo: [date]})."""
    cutoff = (datetime.now(BJT) - timedelta(days=days)).strftime("%Y-%m-%d")
    pushed = [p for p in state.get("pushed", []) if p.get("date", "") >= cutoff]

    url_set = set()
    url_title_list: list[tuple[str, str]] = []
    gh_repo_dates: dict[str, list[str]] = {}

    for p in pushed:
        url = normalize_url(p.get("url", ""))
        title = (p.get("title") or "").strip()
        if url:
            url_set.add(url)
            url_title_list.append((url, title))
        repo = github_repo(p.get("url", ""))
        if repo:
            gh_repo_dates.setdefault(repo, []).append(p.get("date", ""))

    return url_set, url_title_list, gh_repo_dates


# ── 单条去重判定 ──────────────────────────────────────────────────
def _title_similar(a: str, b: str) -> bool:
    if not a or not b:
        return False
    a_n = re.sub(r"\s+", "", a.lower())
    b_n = re.sub(r"\s+", "", b.lower())
    if len(a_n) < 8 or len(b_n) < 8:
        return a_n == b_n
    return SequenceMatcher(None, a_n, b_n).ratio() >= TITLE_SIM_THRESHOLD


def is_dup(item: dict, src_name: str,
           url_set: set[str], url_title_list: list[tuple[str, str]],
           gh_repo_dates: dict[str, list[str]]) -> tuple[bool, str]:
    """返回 (是否重复, 原因)."""
    url = normalize_url(item.get("url", ""))
    title = (item.get("title") or "").strip()

    # L1: URL 完全匹配
    if url and url in url_set:
        return True, "L1 url-dup"

    # L3: GitHub repo (优先 L1, 同 repo 不同 URL 也算重复)
    if src_name and "github" in src_name.lower():
        repo = github_repo(item.get("url", ""))
        if repo and repo in gh_repo_dates:
            return True, f"L3 gh-repo-dup({repo})"

    # L2: 标题模糊
    if title:
        for h_url, h_title in url_title_list:
            if _title_similar(title, h_title):
                return True, f"L2 title-similar({h_title[:30]})"

    return False, ""


# ── 主去重函数 (供 agent.py 调用) ────────────────────────────────
def dedupe_against_history(items: list[dict], src_name: str,
                            state: dict | None = None) -> tuple[list[dict], list[dict]]:
    """对 items 过滤, 返回 (kept, dropped).
    dropped[i] = {"item": ..., "reason": "..."}.
    """
    if state is None:
        state = load_state()
    url_set, url_title_list, gh_repo_dates = get_history_index(state)

    kept, dropped = [], []
    for it in items:
        dup, reason = is_dup(it, src_name, url_set, url_title_list, gh_repo_dates)
        if dup:
            dropped.append({"item": it, "reason": reason})
        else:
            kept.append(it)
    return kept, dropped


# ── 落地: 把今日推送追加进 state ──────────────────────────────────
def record_pushed(state: dict, date_str: str, results: list[dict]) -> None:
    """results: [{name, items: [{title, url, ...}], ...}, ...]"""
    pushed = state.setdefault("pushed", [])
    seen_urls = set()
    for r in results:
        for it in r.get("items", []):
            url = (it.get("url") or "").strip()
            if not url or normalize_url(url) in seen_urls:
                continue
            seen_urls.add(normalize_url(url))
            pushed.append({
                "date": date_str,
                "url": url,
                "title": (it.get("title") or "").strip()[:200],
                "src": r.get("name", "?"),
            })
    trim_history(state)
    save_state(state)


# ── dry-run: 从 daily.md 提取 items 并模拟去重 ─────────────────
_ITEM_RE = re.compile(r"^- \[(?P<title>[^\]]+)\]\((?P<url>[^)]+)\)", re.M)


def _parse_daily_md(md_path: Path) -> list[dict]:
    """从 daily.md 抽所有 'url|title' 行, 不分信源."""
    items = []
    for m in _ITEM_RE.finditer(md_path.read_text(encoding="utf-8")):
        items.append({"title": m.group("title").strip(), "url": m.group("url").strip()})
    return items


def dry_run(md_path: Path) -> int:
    """模拟去重并打印效果, 不修改 state.json."""
    if not md_path.exists():
        print(f"[dedupe] ✗ {md_path} 不存在")
        return 1
    items = _parse_daily_md(md_path)
    if not items:
        print(f"[dedupe] {md_path} 里没抽到条目 (期待 '- [title](url)' 格式)")
        return 1
    state = load_state()
    print(f"[dedupe] dry-run {md_path.name}: 共 {len(items)} 条, 历史窗口 {WINDOW_DAYS} 天 ({len(state.get('pushed', []))} 条历史)\n")

    kept, dropped = dedupe_against_history(items, src_name="", state=state)

    if dropped:
        print(f"  🗑  会去重 ({len(dropped)} 条):")
        for d in dropped:
            t = d["item"].get("title", "?")[:50]
            u = d["item"].get("url", "?")[:60]
            print(f"    [{d['reason']:<25}] {t}")
            print(f"    {'':25}  {u}")
    else:
        print("  ✅ 无重复")

    print(f"\n  📊 结果: {len(items)} → {len(kept)} (去除 {len(dropped)}, {len(dropped)/max(len(items),1)*100:.1f}%)")
    return 0


def init_from_digests(days: int = KEEP_HISTORY_DAYS, exclude_today: bool = True) -> int:
    """从 digests/YYYY-MM-DD-daily.md 扫描, 重建 state.pushed 字段.
    一次性脚本: 已有 state.json 不丢 sources/history, 只 push pushed 字段.

    exclude_today (默认 True): 跳过今天的 daily.md, 避免污染当天的 dedupe 测试.
    """
    state = load_state()
    cutoff = (datetime.now(BJT) - timedelta(days=days)).strftime("%Y-%m-%d")
    today_str = datetime.now(BJT).strftime("%Y-%m-%d")
    pushed = []
    skipped_old = 0
    skipped_today = 0
    files = sorted(DIGEST_DIR.glob("*-daily.md"))
    if not files:
        print(f"[dedupe] init: {DIGEST_DIR} 里没找到 *-daily.md")
        return 1
    for fp in files:
        date_str = fp.name[:10]  # YYYY-MM-DD
        if date_str < cutoff:
            skipped_old += 1
            continue
        if exclude_today and date_str >= today_str:
            skipped_today += 1
            continue
        items = _parse_daily_md(fp)
        for it in items:
            pushed.append({
                "date": date_str,
                "url": it["url"],
                "title": it["title"],
                "src": "?",
            })
    state["pushed"] = pushed
    trim_history(state)
    save_state(state)
    print(f"[dedupe] init OK: 扫描 {len(files)} 个 daily.md")
    print(f"[dedupe]   跳过 {skipped_old} 个超过 {days} 天, 跳过今天 {skipped_today} 个")
    print(f"[dedupe] pushed 字段: {len(pushed)} 条 (回填到 {cutoff} 之前)")
    print(f"[dedupe] 保存到 {STATE}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "--init":
        days = int(sys.argv[2]) if len(sys.argv) > 2 else KEEP_HISTORY_DAYS
        sys.exit(init_from_digests(days))
    if len(sys.argv) < 2:
        # 默认 dry-run 昨天的
        yesterday = (datetime.now(BJT) - timedelta(days=1)).strftime("%Y-%m-%d")
        target = DIGEST_DIR / f"{yesterday}-daily.md"
        if not target.exists():
            today = datetime.now(BJT).strftime("%Y-%m-%d")
            target = DIGEST_DIR / f"{today}-daily.md"
        sys.exit(dry_run(target))
    target = Path(sys.argv[1])
    sys.exit(dry_run(target))
