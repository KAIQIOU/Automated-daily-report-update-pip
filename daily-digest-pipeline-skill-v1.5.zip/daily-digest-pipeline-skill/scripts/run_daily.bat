@echo off
REM daily-digest-agent · v0.2 · Windows 一键跑
REM 建议: 放到 Windows 任务计划程序里, 每天 08:00 触发
REM 流程: agent.py → screening.py → report_html.py → publish 到团队目录

setlocal

REM ── 切到脚本所在目录 ──
cd /d "%~dp0"

REM ── LLM 配置 (MiniMax M3 coding plan) ──
REM 优先读 .env, 没有就用下面默认值
if exist .env (
  for /f "usebackq tokens=1,2 delims==" %%a in (".env") do (
    set "%%a=%%b"
  )
)

if "%LLM_API_KEY%"=="" (
  echo [ERROR] LLM_API_KEY 未设置
  echo         请在 .env 里写 LLM_API_KEY=sk-xxx
  echo         或 set LLM_API_KEY=sk-xxx 后再跑
  exit /b 1
)

if "%LLM_API_BASE%"=="" set "LLM_API_BASE=https://api.MiniMax.chat/v1"
if "%LLM_MODEL%"=="" set "LLM_MODEL=MiniMax-M3"

REM ── 激活 venv (有的话) ──
if exist .venv\Scripts\activate.bat (
  call .venv\Scripts\activate.bat
)

REM ── 跑编排器 ──
python run_daily.py %*
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo [WARN] run_daily.py 退出码 = %RC%, 请看上面的日志
)

endlocal & exit /b %RC%
