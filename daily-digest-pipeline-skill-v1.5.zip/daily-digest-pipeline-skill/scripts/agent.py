#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""daily-digest-agent · v0.1 · 每日信源聚合 → 中文日报"""
from __future__ import annotations
import json, os, re, sys, time, logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
import feedparser  # type: ignore
import requests
from bs4 import BeautifulSoup  # type: ignore

# ── 强制禁用系统代理 (Windows 127.0.0.1:7890 / clash 挂了 → RSS + LLM 全失败) ──
# requests 走 WinHTTP 注册表读代理, feedparser 走 urllib.getproxies, 两处都要禁
import urllib.request as _urllib_request
_urllib_request.getproxies = lambda: {}  # 覆盖默认实现, feedparser 不再走代理
requests.sessions.Session.trust_env = False  # 所有 Session(trust_env) 类属性改 False
# 注: requests.get/post() 内部每次创建新 Session, 上面这个改动会立即生效

# ── 配置 ────────────────────────────────────────────────────────────
BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
SOURCES_FILE = ROOT / "sources.json"
DIGEST_DIR = ROOT / "digests"
DIGEST_DIR.mkdir(exist_ok=True)

LLM_API_KEY = os.environ.get("LLM_API_KEY", "")
LLM_API_BASE = os.environ.get("LLM_API_BASE", "https://api.openai.com/v1").rstrip("/")
LLM_MODEL = os.environ.get("LLM_MODEL", "gpt-4o-mini")
HOURS_WINDOW = int(os.environ.get("HOURS_WINDOW", "24"))
UA = "daily-digest-agent/0.1"
HAS_LLM = bool(LLM_API_KEY)

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("daily-digest")


# ── 抓取 ────────────────────────────────────────────────────────────
def _filter(items: list[dict], hours: int) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    out = []
    for it in items:
        ts = it.get("_ts")
        out.append(it if (ts is None or ts >= cutoff) else None)
    return [x for x in out if x]


def fetch_rss(url: str, max_items: int, hours: int) -> list[dict]:
    feed = feedparser.parse(url, agent=UA)
    if feed.bozo and not feed.entries:
        log.warning("RSS 解析失败 %s: %s", url, getattr(feed, "bozo_exception", ""))
    items: list[dict] = []
    for e in feed.entries[: max_items * 3]:
        ts_struct = e.get("published_parsed") or e.get("updated_parsed")
        ts = None
        if ts_struct:
            try: ts = datetime(*ts_struct[:6], tzinfo=timezone.utc)
            except (TypeError, ValueError): ts = None
        items.append({
            "title":   (e.get("title") or "").strip(),
            "url":     (e.get("link") or "").strip(),
            "summary": re.sub(r"<[^>]+>", "", e.get("summary", "") or "").strip()[:500],
            "ts":      e.get("published", ""),
            "_ts":     ts,
        })
    return _filter(items, hours)[:max_items]


def fetch_github_trending(url: str, max_items: int, hours: int) -> list[dict]:
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=20)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    items: list[dict] = []
    for art in soup.select("article.Box-row")[:max_items]:
        a = art.select_one("h2 a")
        if not a: continue
        href = a.get("href", "").strip()
        full = f"https://github.com{href}" if href.startswith("/") else href
        desc = (art.select_one("p") or art).__str__()
        desc = BeautifulSoup(desc, "html.parser").get_text(" ", strip=True) if "<" in desc else desc
        lang = art.select_one("span[itemprop='programmingLanguage']")
        lang = lang.get_text(strip=True) if lang else ""
        items.append({
            "title":   href.lstrip("/").replace("/", " / "),
            "url":     full,
            "summary": f"[{lang}] {desc[:300]}".strip(),
            "ts":      "today",
            "_ts":     datetime.now(timezone.utc),
        })
    return items


PARSERS: dict[str, Callable[[dict], list[dict]]] = {
    "default_rss":      lambda c: fetch_rss(c["url"], c.get("max_items", 5), HOURS_WINDOW),
    "github_trending":  lambda c: fetch_github_trending(c["url"], c.get("max_items", 10), HOURS_WINDOW),
}


# ── LLM(可选) + 提取式降级 ──────────────────────────────────────────
def call_llm(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
    if not HAS_LLM:
        raise RuntimeError("LLM_API_KEY 未设置")
    r = requests.post(
        f"{LLM_API_BASE}/chat/completions",
        headers={"Authorization": f"Bearer {LLM_API_KEY}", "Content-Type": "application/json"},
        json={"model": LLM_MODEL, "messages": (
            [{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens, "temperature": 0.3},
        timeout=15,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def summarize(name: str, items: list[dict]) -> tuple[str, str]:
    """返回 (摘要, 为什么值得读)。LLM 不可用时降级到提取式。"""
    if not items:
        return ("今日窗口内无更新。", "信源暂未发布新内容, 改天再看")

    # ── LLM 路径 ──
    if HAS_LLM:
        bullet = "\n".join(
            f"- [{it.get('ts', '?')[:16]}] {it['title']}\n  {it['url']}\n  {it.get('summary','')[:250]}"
            for it in items)
        sys_p = "你是一名中文科技资讯编辑, 专注给 vibecoder / agent 工程师做每日信源摘要。简练, 高密度, 不客套。"
        prompt = (f"下面是「{name}」最近 24h 的 {len(items)} 条更新。输出严格两行:\n"
                  f"摘要:<200字, 抓住共同主题和最重要信号, 顿号短句, 不分点>\n"
                  f"值得读:<1 句话, 说明为什么值得点开看>\n\n素材:\n{bullet}")
        out = call_llm(prompt, system=sys_p, max_tokens=500)
        s, w = "", ""
        for line in out.splitlines():
            t = line.strip()
            if t.startswith("摘要"):    s = re.split(r"[:：]", t, 1)[-1].strip()
            elif t.startswith("值得读"): w = re.split(r"[:：]", t, 1)[-1].strip()
        return (s or out[:300].strip(), w or "见摘要")

    # ── 提取式降级(无 LLM 时) ──
    top_titles = " / ".join(it["title"][:50] for it in items[:3])
    summary = (f"今日 {len(items)} 条更新。代表条目: {top_titles}。"
               f"完整列表见下方「原始条目」。")
    why = f"非 LLM 摘要(未设 LLM_API_KEY), 看下方原始条目更快。"
    return summary, why


# ── Markdown 渲染 ───────────────────────────────────────────────────
def _esc(t: str) -> str:
    return t.replace("|", "｜").replace("\n", " ").strip()


def render(date_str: str, results: list[dict]) -> str:
    L: list[str] = [
        f"# 每日信源摘要 · {date_str}",
        "",
        f"> {len(results)} 个信源 · 生成 {datetime.now(BJT):%H:%M} (UTC+8) · v0.1"
        + (" · LLM: ON" if HAS_LLM else " · LLM: OFF (提取式)"),
        "",
        "## 总览",
        "",
        "| # | 信源 | 摘要(节选) | 值得读 |",
        "|---|------|------------|--------|",
    ]
    for i, r in enumerate(results, 1):
        L.append(f"| {i} | {r['name']} | {_esc(r['summary'])[:80]} | {_esc(r['why'])[:60]} |")
    L.append("")

    for i, r in enumerate(results, 1):
        L += [
            f"## {i}. {r['name']}",
            "",
            f"**信源**: <{r['url']}>  ",
            f"**抓取条数**: {r['count']}  ",
            "",
            "**摘要**",
            "",
            r["summary"],
            "",
            f"**为什么值得读**: {r['why']}",
            "",
        ]
        if r.get("items"):
            L.append(f"<details><summary>原始条目 ({len(r['items'])} 条)</summary>")
            L.append("")
            for it in r["items"][:8]:
                L.append(f"- [{_esc(it['title'])}]({it['url']})")
            L.append("")
            L.append("</details>")
            L.append("")
        L.append("---")
        L.append("")
    return "\n".join(L)


# ── 主流程 ──────────────────────────────────────────────────────────
def run() -> Path:
    sources = json.loads(SOURCES_FILE.read_text(encoding="utf-8"))
    date_str = datetime.now(BJT).strftime("%Y-%m-%d")
    out_path = DIGEST_DIR / f"{date_str}-daily.md"

    # ── 加载跨日去重状态 (state.json.pushed 滑动窗口) ──
    try:
        from dedupe import dedupe_against_history, record_pushed, load_state as _load_dedupe_state
        dedupe_state = _load_dedupe_state()
    except Exception as e:
        log.warning("dedupe 模块加载失败 (跳过去重): %s", e)
        dedupe_state = None

    log.info("=" * 60)
    log.info("daily-digest v0.2 · %s · %d 源 · LLM=%s", date_str, len(sources), "ON" if HAS_LLM else "OFF")
    log.info("=" * 60)

    results: list[dict] = []
    total_raw = 0
    total_kept = 0
    total_dup = 0
    for src in sources:
        name = src.get("name", "?")
        url  = src.get("url", "")
        log.info("→ %s", name)
        fn = PARSERS.get(src.get("parser"))
        if not fn:
            log.error("未知 parser=%s, 跳过", src.get("parser")); continue
        try:
            items = fn(src); log.info("   抓到 %d 条", len(items))
        except Exception as e:
            log.exception("   抓取失败: %s", e)
            results.append({"name": name, "url": url, "count": 0,
                            "summary": f"抓取失败: {type(e).__name__}: {str(e)[:120]}",
                            "why": "请检查网络或信源 URL", "items": []}); continue
        total_raw += len(items)

        # ── 跨日去重 (L1 URL / L2 title-similar / L3 GitHub repo) ──
        if dedupe_state is not None:
            kept, dropped = dedupe_against_history(items, name, state=dedupe_state)
            if dropped:
                sample = ", ".join(d["reason"].split("(")[0] for d in dropped[:3])
                log.info("   🗑  去重 %d 条 (L1/L2/L3): %s%s", len(dropped), sample, "..." if len(dropped) > 3 else "")
            items = kept
            total_dup += len(dropped)

        total_kept += len(items)
        try:
            summary, why = summarize(name, items)
            log.info("   ✓ 摘要 %d 字", len(summary))
        except Exception as e:
            log.exception("   总结失败: %s", e)
            summary, why = f"总结失败: {type(e).__name__}", str(e)[:120]
        results.append({"name": name, "url": url, "count": len(items),
                        "summary": summary, "why": why, "items": items})
        time.sleep(0.3)

    out_path.write_text(render(date_str, results), encoding="utf-8")
    log.info("[OK] write %s (%d bytes)", out_path, out_path.stat().st_size)
    log.info("[OK] 去重: 抓 %d → 留 %d (去除 %d 条跨日重复)", total_raw, total_kept, total_dup)

    # ── 把今日推送的 url+title 追加进 state.pushed (供下次去重) ──
    if dedupe_state is not None:
        try:
            record_pushed(dedupe_state, date_str, results)
            log.info("[OK] state.pushed 已更新 (%d 源)", len(results))
        except Exception as e:
            log.warning("state.pushed 更新失败: %s", e)

    return out_path


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
