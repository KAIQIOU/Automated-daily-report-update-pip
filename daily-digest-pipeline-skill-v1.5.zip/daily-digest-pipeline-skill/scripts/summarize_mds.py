#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""summarize_mds.py · v0.4 · LLM 读 markitdown 后的 md, 输出 "内容总结 + 对我们价值"

输入:  md.材料/*.md  (按文件名排序, 12 个)
输出:  digests/{date}-summaries.json  含 12 条:
  {
    "file": "01-xxx.md",
    "title": "<原标题>",
    "url": "<原 url>",
    "src_name": "<源名>",
    "theme": "<3 主题之一>",
    "summary": "<讲了什么, 2-3 句>",
    "value": "<对我们有啥用, 1-2 句>",
    "key_points": ["<bullet1>", "<bullet2>", "<bullet3>"]
  }

用法:  python summarize_mds.py <date> <md_dir>
"""
from __future__ import annotations
import json, re, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from llm_client import is_configured, chat
except ImportError:
    is_configured = lambda: False
    chat = None

BJT = timezone(timedelta(hours=8))
ROOT = Path(__file__).resolve().parent
DIGEST_DIR = ROOT / "digests"

# 3 主题 (按文件名顺序预分组)
THEME_MAP = {
    "01-andrewyng-aisuite.md":                  ("AI 工具与 Agent (能立刻动手)",   "GitHub · andrewyng/aisuite",            "https://github.com/andrewyng/aisuite"),
    "02-datawhalechina-hello-agents.md":         ("AI 工具与 Agent (能立刻动手)",   "GitHub · datawhalechina/hello-agents",   "https://github.com/datawhalechina/hello-agents"),
    "03-rohitg00-ai-engineering-from-scratch.md":("AI 工具与 Agent (能立刻动手)",   "GitHub · rohitg00/ai-engineering-from-scratch", "https://github.com/rohitg00/ai-engineering-from-scratch"),
    "04-juejin-agent-toolcall.md":               ("AI 工具与 Agent (能立刻动手)",   "掘金 · Agent ToolCall 循环定制",         "https://juejin.cn/post/7652005289676636194"),
    "05-juejin-timestamp-trap.md":               ("数据工程与 AI 工程实践",          "掘金 · 静默吞数据的时间戳陷阱",         "https://juejin.cn/post/7652194092412370982"),
    "06-juejin-mybatis-pagination.md":           ("数据工程与 AI 工程实践",          "掘金 · MyBatis 分页后置过滤坑",         "https://juejin.cn/post/7652180405777219594"),
    "07-juejin-agentscope-weather.md":           ("数据工程与 AI 工程实践",          "掘金 · AgentScope 多 Agent 天气助手",   "https://juejin.cn/post/7651959891603079183"),
    "08-claude-founders-playbook.md":            ("数据工程与 AI 工程实践",          "Anthropic · The founder's playbook",     "https://claude.com/blog/the-founders-playbook"),
    "09-qbitai-具身大脑融资.md":                  ("行业趋势与战略 (视野与决策)",      "量子位 · 具身大脑公司数亿美元融资",     "https://www.qbitai.com/2026/06/436148.html"),
    "10-qbitai-卜拉格亮相.md":                    ("行业趋势与战略 (视野与决策)",      "量子位 · 林俊旸卜拉格首轮估值 135 亿",  "https://www.qbitai.com/2026/06/436138.html"),
    "11-qbitai-grok-bedrock.md":                 ("行业趋势与战略 (视野与决策)",      "量子位 · Grok 4.3 上 Amazon Bedrock",  "https://www.qbitai.com/2026/06/436134.html"),
    "12-36kr-逆矩阵融资.md":                      ("行业趋势与战略 (视野与决策)",      "36 氪 · 逆矩阵超亿美元融资",            "https://36kr.com/p/3826129009234824"),
}

# LLM prompt: 总结 + 价值 + 3 个偏好字段 (v0.3 用户明确要求保留)
SUMMARY_PROMPT = """你是数据分析 + AI 应用方向的策展人,帮 vibecoder 团队读一篇刚 markitdown 转出来的文章。

【文章标题】{title}
【来源】{src}
【md 正文前 6000 字】:
{body}

请严格按 JSON 输出 (不要 markdown 围栏, 不要解释):
{{
  "summary": "<1-2 句讲清楚这篇到底讲了什么 (中文, ≤80 字)>",
  "value": "<站在数据分析 / AI 应用 / vibecoder 视角, 这篇对我们有啥用 (1-2 句, 中文, ≤80 字)>",
  "key_points": ["<1 句要点 1>", "<1 句要点 2>", "<1 句要点 3>"],
  "star": <1-5 整数, 5 最高, 按下面口径给分>,
  "why_read": "<1 句话中文, 站在读者角度告诉他为什么值得读 (≤40 字)>",
  "pub_date": "<文章发布日期, 严格按 YYYY-MM-DD 格式; 无法确定时从 md 头/URL/上下文推断一个最合理的; 真不知道给空字符串>"
}}

评分口径 (star):
- 5 必读 (突破性 / 颠覆性 / 极强实操价值)
- 4 值得读 (新范式 / 强可复用方法论)
- 3 可看 (合格信息增量)
- 2 扫一眼 (老调重弹)
- 1 跳过 (噪音 / 标题党)

why_read 写作要求: 从读者视角, 1 句话勾出"跟我有什么关系 / 读这篇能得到什么", 不要复述标题。

pub_date 推断方法: 看 md 顶部有无日期 (发布/更新/创建), URL 路径里有没有 YYYY/MM/DD, 文末 "编辑于"/"发表于" 之类; 三者都找不到再空串。
"""


def _strip_md_noise(md: str) -> str:
    """去掉 markitdown 输出的 chrome / 导航 / footer 等噪音, 保留正文."""
    lines = md.splitlines()
    # 去掉开头连续的导航行 (qbitai/掘金/各种站点首页导航是连续 '* [首页]' '* [资讯]' 这种列表)
    while lines and (
        re.match(r"^\s*[*\-]\s*\[", lines[0])   # 列表项式导航
        or re.match(r"^\s*\*\s*\[", lines[0])
        or re.match(r"^\s*扫码关注", lines[0])   # qbitai 微信二维码
        or re.match(r"^\s*\[", lines[0])         # 纯链接
        or lines[0].strip() == ""
    ):
        if re.match(r"^\s*[*\-]\s*\[", lines[0]) or re.match(r"^\s*\*\s*\[", lines[0]) or re.match(r"^\s*扫码关注", lines[0]):
            lines.pop(0)
        else:
            # 连续空行/链接, 跳到第一个非空
            lines.pop(0)
    md = "\n".join(lines)
    # 去掉 markdown 图片
    md = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", md)
    # 去掉 markdown 链接, 保留文字
    md = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", md)
    # 去掉 HTML 注释
    md = re.sub(r"<!--.*?-->", "", md, flags=re.S)
    # 去掉空行
    md = re.sub(r"\n{3,}", "\n\n", md)
    return md.strip()


def _extract_title(md: str) -> str:
    """从 md 找最像标题的 H1/H2 (跳过 logo / 文件列表)."""
    # 优先 H1
    candidates = []
    for m in re.finditer(r"^#\s+(.+)$", md, re.M):
        t = m.group(1).strip()
        if len(t) < 5: continue
        if "├──" in t or "└──" in t: continue
        if "/" in t and "." in t: continue
        if t.lower() in ("aisuite", "readme", "hello-agents"): continue
        candidates.append(t)
    if candidates:
        return max(candidates, key=len)
    # 没 H1 就用 H2
    candidates = []
    SKIP_H2 = {"star history", "license", "contributing", "about", "releases",
               "contributors", "footer", "links", "acknowledgments", "support",
               "贡献者", "许可证", "关于", "致谢", "联系", "项目结构", "目录结构"}
    SKIP_H2_PREFIX = ("from the creator of",)
    for m in re.finditer(r"^##\s+(.+)$", md, re.M):
        t = m.group(1).strip()
        # 去掉 emoji + markdown 链接
        t_clean = re.sub(r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F600-\U0001F64F]", "", t).strip()
        t_clean = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t_clean).strip()
        if len(t_clean) < 3: continue
        if t_clean.lower() in SKIP_H2: continue
        if t_clean.lower().startswith(SKIP_H2_PREFIX): continue
        candidates.append(t_clean)
    if candidates:
        # 取最长的 (更有信息量), 但要 > 3 字符
        return max(candidates, key=len)
    return "?"


def _fallback_body(raw: str) -> str:
    """LLM 失败时, 从 md 跳过 nav 直接从第一个 H1/H2 之后取 500 字."""
    lines = raw.splitlines()
    start = 0
    for i, line in enumerate(lines):
        if re.match(r"^#{1,3}\s+\S", line) and i > 3:  # 跳过开头 nav 找到真正的标题
            start = i + 1
            break
    body = "\n".join(lines[start:start + 50])
    body = _strip_md_noise(body)
    return body[:500] if body else raw[:500]


def _summarize_one(md_path: Path, theme: str, src: str, url: str) -> dict:
    raw = md_path.read_text(encoding="utf-8", errors="ignore")
    title = _extract_title(raw)
    fallback = {
        "file": md_path.name,
        "title": title,
        "url": url,
        "src_name": src,
        "theme": theme,
        "summary": _clean_pub_date_noise(_fallback_body(raw)[:200]),
        "value": "见原文",
        "key_points": [],
        "star": 3,
        "why_read": "值得一看",
        "pub_date": _guess_pub_date_from_md(raw, url),
        "llm_failed": True,
    }
    if not is_configured() or chat is None:
        fallback["llm_failed"] = "no_key"
        return fallback
    # 1) 主调用: 4000 字 (优化: 跳过 6000 → 节省 ~30%/篇, 防 LLM 慢)
    # 2) 失败 → 重试 2000 字 (短摘要)
    # 3) 还失败 → fallback (不再 retry, 防 30s/篇)
    parsed = _call_llm(title, src, raw, body_limit=4000)
    if parsed is None:
        parsed = _call_llm(title, src, raw, body_limit=2000)
    if parsed is None:
        return fallback
    star_raw = parsed.get("star", 3)
    try:
        star = max(1, min(5, int(star_raw)))
    except (TypeError, ValueError):
        star = 3
    return {
        "file": md_path.name,
        "title": title,
        "url": url,
        "src_name": src,
        "theme": theme,
        "summary": str(parsed.get("summary", ""))[:200],
        "value":    str(parsed.get("value", ""))[:200],
        "key_points": [str(x)[:120] for x in (parsed.get("key_points") or [])][:5],
        "star": star,
        "why_read": str(parsed.get("why_read", ""))[:80] or "值得一看",
        "pub_date": _norm_pub_date(parsed.get("pub_date")) or _guess_pub_date_from_md(raw, url),
    }


def _smart_truncate(text: str, limit: int) -> str:
    """智能截断: 开头 + ... + 末尾 (保留正文完整度, 防 LLM 截断后返非 JSON).

    - text < limit: 原样返回
    - text >= limit: 开头 60% + \\n...[省略]...\\n + 末尾 40%, 总长 ≤ limit
    """
    if len(text) <= limit:
        return text
    head_n = int(limit * 0.6)
    tail_n = limit - head_n - 12  # 留 12 字符给省略标记
    return text[:head_n] + "\n...[省略]...\n" + text[-tail_n:]


def _call_llm(title: str, src: str, raw: str, body_limit: int) -> dict | None:
    """单次 LLM 调用, 成功返回 parsed dict, 失败 (异常/非 JSON) 返回 None."""
    body = _smart_truncate(_strip_md_noise(raw), body_limit)
    try:
        prompt = SUMMARY_PROMPT.format(title=title, src=src, body=body)
        content = chat(
            messages=[
                {"role": "system", "content": "你是严谨的中文 AI/数据 内容策展人, 输出严格 JSON。"},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.2,
            max_tokens=1500,
        )
        content = re.sub(r"<think>.*?</think>", "", content, flags=re.S).strip()
        if content.startswith("```"):
            content = content.split("```", 2)[1]
            if content.startswith("json"):
                content = content[4:]
            content = content.strip()
        return json.loads(content)
    except Exception as e:
        print(f"[summarize] WARN (limit={body_limit}) {title[:30]}: {type(e).__name__}", file=sys.stderr)
        return None


_PUB_RE = re.compile(r"(20\d{2})[-./](\d{1,2})[-./](\d{1,2})")
_URL_DATE_RE = re.compile(r"/(20\d{2})/(\d{1,2})/(\d{1,2})/")


def _norm_pub_date(v) -> str:
    """LLM 偶尔会输出 '2026 年 6 月 17 日' 这类, 规整为 YYYY-MM-DD; 无法规整返回 ''."""
    if not v:
        return ""
    s = str(v).strip()
    m = _PUB_RE.search(s)
    if m:
        y, mo, d = m.groups()
        try:
            return f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"
        except ValueError:
            return ""
    return ""


def _guess_pub_date_from_md(raw: str, url: str) -> str:
    """从 md 头部 / URL 推断 pub_date (3 种方式: 头 30 行找日期, URL 路径, 看 '发布于'/'更新于'/'文' 等)."""
    head = "\n".join(raw.splitlines()[:30])
    m = _PUB_RE.search(head)
    if m:
        y, mo, d = m.groups()
        try:
            return f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"
        except ValueError:
            pass
    if url:
        m = _URL_DATE_RE.search(url)
        if m:
            y, mo, d = m.groups()
            try:
                return f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"
            except ValueError:
                pass
    return ""


def _clean_pub_date_noise(s: str) -> str:
    """fallback 摘要里把 '2026-06-17\\n0\\n阅读12分钟' 之类的噪音干掉."""
    if not s:
        return s
    s = re.sub(r"^\d{4}-\d{2}-\d{2}\s*\n", "", s)
    s = re.sub(r"^\d+\s*\n", "", s)
    s = re.sub(r"阅读\d+分钟", "", s)
    return s.strip()[:180]


def _load_manifest(md_dir: Path) -> dict:
    """读 markitdown_automate.py 生成的 manifest.json (动态主题映射)."""
    p = md_dir / "manifest.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[summarize] WARN manifest.json 解析失败: {e}", file=sys.stderr)
        return {}


def _lookup_file_meta(md_dir: Path, filename: str) -> tuple[str, str, str]:
    """查 (theme, src_name, url). 优先 manifest.json (动态), fallback 硬编码 THEME_MAP."""
    manifest = _load_manifest(md_dir)
    if filename in manifest:
        m = manifest[filename]
        return (m.get("theme", "未分类"), m.get("src_name", filename), m.get("url", ""))
    return THEME_MAP.get(filename, ("未分类", filename, ""))


def run(date_str: str, md_dir: Path, out_dir: Path | None = None) -> Path:
    if not md_dir.is_dir():
        raise FileNotFoundError(f"未找到 {md_dir}, 先跑 markitdown 批量转")

    target_dir = out_dir or DIGEST_DIR
    target_dir.mkdir(parents=True, exist_ok=True)

    manifest = _load_manifest(md_dir)
    print(f"[summarize] 读 {len(list(md_dir.glob('*.md')))} 个 md → LLM 总结 (out={target_dir}, manifest={'OK' if manifest else 'fallback THEME_MAP'})")

    out = []
    files = sorted(md_dir.glob("*.md"))
    for f in files:
        theme, src, url = _lookup_file_meta(md_dir, f.name)
        s = _summarize_one(f, theme, src, url)
        # Windows GBK 控制台不支持所有 unicode 字符, 用 ascii-safe 输出
        safe_name = f.name.encode('ascii', 'replace').decode('ascii')[:35]
        safe_sum = s['summary'][:60].encode('ascii', 'replace').decode('ascii')
        print(f"  [{safe_name:<35}] {safe_sum}")
        out.append(s)

    json_data = {
        "date": date_str,
        "generated_at": datetime.now(BJT).isoformat(),
        "version": "0.4",
        "llm": "ON" if is_configured() else "OFF",
        "themes": [
            "AI 工具与 Agent (能立刻动手)",
            "数据工程与 AI 工程实践",
            "行业趋势与战略 (视野与决策)",
        ],
        "summaries": out,
    }
    json_path = target_dir / f"{date_str}-summaries.json"
    json_path.write_text(json.dumps(json_data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[summarize] OK {json_path} ({len(out)} 条)")
    return json_path


if __name__ == "__main__":
    """用法: python summarize_mds.py [date] [md_dir] [out_dir]
    date    默认今天 (BJT)
    md_dir  默认 <日报>/半自动日报更新/{date}-daily-V1.0/{date} md.材料
    out_dir 默认 daily-digest-agent/digests/  (V1.x: 传 V1.1 文件夹路径)
    """
    date = sys.argv[1] if len(sys.argv) > 1 else datetime.now(BJT).strftime("%Y-%m-%d")
    # 默认 md_dir: 跟项目根同级的 半自动日报更新/ 文件夹, 自动跟随整个 日报/ 目录搬移
    md_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else (
        Path(__file__).resolve().parent.parent / "半自动日报更新" / f"{date}-daily-V1.0" / f"{date} md.材料"
    )
    out_dir = Path(sys.argv[3]) if len(sys.argv) > 3 else None
    sys.exit(0 if run(date, md_dir, out_dir) else 1)
