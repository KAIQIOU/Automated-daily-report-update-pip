# daily-digest-pipeline-skill · v1.5

> Self-contained skill 包: 任何 agent 拿到手, 从零跑出"数据分析 + AI 应用方向"的**每日中文日报**, 视觉与产物严格一致。
>
> **核心**: 9 源 + 3 主题 + LLM 总结 + 4 tab 切换单文件 HTML + 飞书 DM 发送 + Bitable 同步 + 双 verify 10:40 兜底。
>
> **v1.5 (2026-07-03)** = v1.4 跨代改 5 项 + 7 运营脚本 + run_daily.py 一键 + 3 段时间窗 (实测稳定 6-30 → 7-3, 4 天全 rc=0)。

**入口**: 阅读 [SKILL.md](SKILL-半自动化日报.md) (含完整 SOP + 偏好 + 命名 + 验收)。

## 结构

```
daily-digest-pipeline-skill/
├── SKILL-半自动化日报.md    ← 主文档 (从这里开始读)
├── README.md                ← 本文件
├── scripts/                 ← 8 个核心 python 脚本
│   ├── agent.py             ← 抓 RSS (v1.4 禁代理 patch)
│   ├── llm_client.py        ← LLM 客户端 (v1.4 timeout 60s)
│   ├── markitdown_automate.py ← (v1.4 新增) md 转换 + manifest.json + 反爬
│   ├── summarize_mds.py     ← LLM 总结 (v1.4 _smart_truncate + _load_manifest)
│   ├── report_html_v04.py   ← 渲染单文件 HTML (v1.2 TOP 4)
│   ├── dedupe.py            ← 跨日去重 (v1.2 state.pushed 14 天)
│   ├── run_daily.py         ← (v1.4 新增) 5 步一键编排 + publish
│   ├── run_daily.bat        ← (v1.4 新增) Windows 一键跑
│   ├── install_cron.bat     ← (v1.4 新增) schtasks 注册
│   └── digests/             ← 中间产物
├── ops/                     ← 7 个运营脚本 (飞书 + Bitable)
│   ├── send_daily_report.py    ← 飞书 SDK 上传 + DM
│   ├── send_daily_report.bat   ← Windows 一键发
│   ├── sync_to_bitable.py      ← 飞书云盘 + Bitable 同步
│   ├── verify_bitable_sync.py  ← 硬验证 (4 状态码)
│   ├── verify_and_recover.bat  ← 10:40 兜底
│   ├── _send_daily_scan.ps1    ← 扫今天目录 + 串 3 个 py
│   └── BRIEF_科技日报自动化.md ← 投递 agent ↔ Clove 协作 BRIEF
├── config/
│   ├── .env.example         ← LLM_API_KEY 模板
│   ├── sources.example.json ← 9 信源配置
│   └── requirements.txt     ← Python 依赖
└── docs/                    ← 进阶主题 (按需读)
    ├── css-tab-trick.md
    ├── preference-design.md
    ├── naming-convention.md
    ├── pitfalls.md
    ├── markitdown-automate.md    ← (v1.4 新增) 反爬 + manifest 详解
    ├── bitable-sync.md           ← (v1.4 新增) 飞书 Bitable 同步 + 硬验证
    ├── run-daily-cmd.md          ← (v1.4 新增) 5 步一键 + 任务计划
    └── windows-bat-pits.md       ← (v1.4 新增) bat 6 大坑
```

## 3 分钟上手

```bash
# 1) 准备配置
cp config/.env.example .env
# 填 LLM_API_KEY (MiniMax / OpenAI / DeepSeek 任意)
cp config/sources.example.json sources.json  # 可保持默认
pip install -r config/requirements.txt       # requests, beautifulsoup4, feedparser
pip install markitdown[lxml]                 # markitdown CLI (转 md 用)

# 2) 跑 5 步 (一键)
cd scripts/
python run_daily.py 2026-07-03
# 产出: 半自动日报更新/科技日报V1.0-2026-7-3/ (3 文件 + md.材料/)

# 3) 发飞书 DM + Bitable (运营层)
cd ../ops/
send_daily_report.bat                                      # Mode 2: 扫今天目录自动发
python verify_bitable_sync.py 2026-07-03                   # 硬验证

# 4) 注册任务计划 (可选, 每天 08:00 自动跑)
cd ../scripts/
install_cron.bat                                           # 需要管理员权限
```

## 关键约束 (用户硬要求, 详见 SKILL.md §2)

- ❌ **不静默覆盖** 旧版 (V1.0 → V1.1 → V1.2)
- ❌ **不删 v0.3 不错功能** (star/why_read/pub_date)
- ❌ **不用 emoji 当 icon**
- ❌ **不要 anchor 滚动 tab** (用纯 CSS radio)
- ❌ **不要让 Bitable 用磁盘原始命名** (一律"科技日报 YYYY-MM-DD")

## 3 段时间窗 (推荐配置)

```
08:00  install_cron.bat     → run_daily.py  (任务计划)
09:50  (Clove 备份 cron)    → run_daily.py  (08:00 失败兜底)
10:10  send_daily_report.bat → 飞书 DM + Bitable + verify
10:40  verify_and_recover.bat → 兜底 (缺/不规范 → 自动 re-send + 再 verify)
```

**实测稳定** (2026-06-30 → 2026-07-03, 4 天): bat end 全 `rc=0`, 10:40 全 OK 没触发 re-send。

## v1.2 → v1.5 升级清单

| 模块 | v1.2 (旧) | v1.5 (新) | 原因 |
|---|---|---|---|
| agent.py | 没禁代理 | +禁系统代理 patch | Windows clash 挂 → 全失败 |
| llm_client.py | timeout 15s | +60s | MiniMax M3 长 prompt 慢 |
| summarize_mds.py | 硬截断 | +_smart_truncate (60%+40%) | 截断后 LLM 返非 JSON |
| summarize_mds.py | THEME_MAP 硬编码 | +_load_manifest 动态映射 | 重跑漏覆盖 |
| summarize_mds.py | 6000/4000/2500 | 4000/2000 2 段 | 节省 30%/篇 |
| markitdown_automate.py | (没在 skill 包) | +_http_get_no_proxy + BYPASS 8 站 | curl 走 WinHTTP 代理挂 |
| markitdown_automate.py | (没在 skill 包) | +清空旧 md | manifest 不覆盖 |
| markitdown_automate.py | (没在 skill 包) | +manifest.json 自动生成 | 动态主题映射 |
| report_html_v04.py | (skill 包 v1.1) | +TOP_N_PER_THEME=4 | 每主题 4 条 |
| run_daily.py | (没在 skill 包) | +一键编排 | 5 步全自动 |
| install_cron.bat | (没在 skill 包) | +schtasks 注册 | 任务计划 |
| ops/ (7 脚本) | (没在 skill 包) | +send + sync + verify + recover | 飞书 DM + Bitable |

## 常见坑 (跨项目通用)

详见 [docs/windows-bat-pits.md](docs/windows-bat-pits.md) + [docs/markitdown-automate.md](docs/markitdown-automate.md) + [docs/bitable-sync.md](docs/bitable-sync.md)。

最常见的 3 个:
1. **Windows 系统代理 127.0.0.1:7890 (clash 挂)**: agent.py:11-18 禁代理 patch 必须带
2. **bat GBK 编码 + 中文路径**: cp936/ANSI + powershell 算 ISO timestamp
3. **Python 路径版本敏感**: bat 顶部加注释 "升级后改下一行"

## 详细流程

[SKILL-半自动化日报.md](SKILL-半自动化日报.md) (主文档, 从这里开始读)
