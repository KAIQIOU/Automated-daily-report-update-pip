@echo off
setlocal
set HERMES_PY=%USERPROFILE%\.agent-web-ui\desktop-runtime\agent\0.15.2\win-x64\python\python.exe
set SCRIPT_DIR=%~dp0
set BASE=./daily-reports
set LOG=%SCRIPT_DIR%send_daily_report_cron.log

rem === ISO timestamp via powershell (locale-safe) ===
for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"') do set TS=%%I

echo.>> "%LOG%"
echo === %TS% bat start ===>> "%LOG%"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_send_daily_scan.ps1" 1>>"%LOG%" 2>&1
set RC=%ERRORLEVEL%

for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"') do set TS=%%I
echo === %TS% bat end rc=%RC% ===>> "%LOG%"

exit /b %RC%
