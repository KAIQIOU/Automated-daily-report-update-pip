#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
send_daily_report.py
把日报 HTML 作为附件发到飞书 DM (收件人 chat_id 来自 .env FEISHU_DM_CHAT_ID)。

Usage:
  python send_daily_report.py <html_path> [chat_id] [--dry-run]
  chat_id 参数优先级: CLI 第二参 > .env FEISHU_DM_CHAT_ID, 都没设则 FAIL。

环境变量:
  FEISHU_DM_CHAT_ID          飞书 DM chat_id (oc_... 开头)

依赖: lark-oapi, pyyaml (装在 agent 嵌入式 python 里)
"""

import sys, os
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        os.environ["PYTHONIOENCODING"] = "utf-8"

import re, json, yaml
import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateFileRequest, CreateFileRequestBody,
    CreateMessageRequest, CreateMessageRequestBody,
)

DATE_PATTERN = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})")


def canonical_daily_name(html_path):
    """从 path 或 文件名提取日期, 返回规范名 '科技日报 YYYY-MM-DD.html'。
    用于飞书 DM 附件名 (2026-06-24 用户约定, Bitable 同理)。
    """
    candidates = [os.path.basename(os.path.dirname(html_path)), os.path.basename(html_path)]
    for src in candidates:
        m = DATE_PATTERN.search(src)
        if m:
            y, mo, dd = m.groups()[:3]
            return "科技日报 " + ("%04d-%02d-%02d" % (int(y), int(mo), int(dd))) + ".html"
    # fallback: 原文件名
    return os.path.basename(html_path)

def load_feishu_creds():
    cfg_path = os.path.expanduser(r"~/.daily-digest/config.yaml")
    with open(cfg_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    feishu = cfg.get("platforms", {}).get("feishu", {}).get("extra", {})
    return feishu["app_id"], feishu["app_secret"]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    dry_run = "--dry-run" in flags

    if len(args) < 1:
        print("usage: send_daily_report.py <html_path> [chat_id] [--dry-run]")
        sys.exit(1)

    html_path = args[0]
    chat_id = args[1] if len(args) > 1 else os.environ.get("FEISHU_DM_CHAT_ID")
    if not chat_id:
        print("FAIL: chat_id 缺; 配 .env FEISHU_DM_CHAT_ID 或 CLI 传 <chat_id>", file=sys.stderr)
        sys.exit(1)

    if not os.path.exists(html_path):
        print(f"FAIL: file not found: {html_path}")
        sys.exit(1)

    app_id, app_secret = load_feishu_creds()
    print(f"[creds] app_id={app_id[:10]}... chat_id={chat_id}")

    client = lark.Client.builder() \
        .app_id(app_id) \
        .app_secret(app_secret) \
        .domain("https://open.feishu.cn") \
        .build()

    src_name = os.path.basename(html_path)
    file_name = canonical_daily_name(html_path)
    file_size = os.path.getsize(html_path)
    print(f"[upload] {file_name} ({file_size} bytes) type=stream (本地源={src_name})")

    # 1) 上传
    with open(html_path, "rb") as f:
        req = CreateFileRequest.builder() \
            .request_body(CreateFileRequestBody.builder()
                .file_type("stream")
                .file_name(file_name)
                .file(f)
                .build()) \
            .build()
        up_resp = client.im.v1.file.create(req)

    if up_resp.code != 0:
        print(f"FAIL: upload error code={up_resp.code} msg={up_resp.msg}")
        sys.exit(2)
    file_key = up_resp.data.file_key
    print(f"[upload] OK file_key={file_key}")

    if dry_run:
        print("[dry-run] skip send_message")
        print(f"OK dry-run: file_key={file_key}  upload_as={file_name}")
        return

    # 2) 发文件消息
    body = CreateMessageRequestBody.builder() \
        .receive_id(chat_id) \
        .msg_type("file") \
        .content(json.dumps({"file_key": file_key})) \
        .build()
    req = CreateMessageRequest.builder() \
        .receive_id_type("chat_id") \
        .request_body(body) \
        .build()
    send_resp = client.im.v1.message.create(req)

    if send_resp.code != 0:
        print(f"FAIL: send error code={send_resp.code} msg={send_resp.msg}")
        sys.exit(3)
    msg_id = send_resp.data.message_id
    print(f"[send] OK message_id={msg_id} chat_id={send_resp.data.chat_id}")
    print(f"\n[OK] HTML 附件已发到飞书: {file_name}")


if __name__ == "__main__":
    main()
