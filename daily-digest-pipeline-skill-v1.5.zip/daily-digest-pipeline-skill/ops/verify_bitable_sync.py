#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_bitable_sync.py
校验当天日报是否真的写进了 Bitable 科技日报-每日更新。

必填环境变量 (在 .env 配):
  FEISHU_BITABLE_APP_TOKEN     飞书 Bitable 应用 token (base58 字符串)
  FEISHU_BITABLE_TABLE_ID      飞书 Bitable table_id (tbls... 开头)

退出码 (硬约定,verify_and_recover.bat / schtasks 都靠这个):
  0 = OK         记录存在 + 日报名 = "科技日报 YYYY-MM-DD" + 产出附件齐全
  1 = MISSING    当天无记录
  2 = MISMATCH   记录存在但 日报名 / 附件名 不规范
  3 = API_ERROR  飞书 token / API 失败

Usage:
  python verify_bitable_sync.py [YYYY-MM-DD]
  默认: 北京时区当天

依赖: requests, pyyaml (agent 嵌入式 python 自带)
"""
import os
import sys
import yaml
import requests
from datetime import datetime, timezone, timedelta

APP_TOKEN = os.environ.get("FEISHU_BITABLE_APP_TOKEN")
TABLE_ID  = os.environ.get("FEISHU_BITABLE_TABLE_ID")

if not APP_TOKEN or not TABLE_ID:
    raise RuntimeError(
        "FEISHU_BITABLE_APP_TOKEN / FEISHU_BITABLE_TABLE_ID 未配置, 在 .env 填上"
    )


def get_today_cn():
    cn = timezone(timedelta(hours=8))
    return datetime.now(cn).strftime("%Y-%m-%d")


def load_creds():
    cfg_path = os.path.expanduser(r"~/.daily-digest/config.yaml")
    with open(cfg_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    feishu = cfg.get("platforms", {}).get("feishu", {}).get("extra", {})
    return feishu["app_id"], feishu["app_secret"]


def get_token(app_id, app_secret):
    r = requests.post(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": app_id, "app_secret": app_secret},
        timeout=15,
    )
    r.raise_for_status()
    return r.json()["tenant_access_token"]


def find_record(token, target_date):
    """Search Bitable for record with 日报日期 == target_date."""
    r = requests.post(
        f"https://open.feishu.cn/open-apis/bitable/v1/apps/{APP_TOKEN}/tables/{TABLE_ID}/records/search",
        headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"},
        json={
            "filter": {
                "conjunction": "and",
                "conditions": [{
                    "field_name": "日报日期",
                    "operator": "is",
                    "value": [target_date],
                }],
            },
            "page_size": 5,
        },
        timeout=15,
    )
    j = r.json()
    if j.get("code") != 0:
        return None, "API error code=" + str(j.get("code")) + " msg=" + str(j.get("msg"))
    items = j["data"]["items"]
    if not items:
        return None, None
    return items[0], None


def main():
    target_date = sys.argv[1] if len(sys.argv) > 1 else get_today_cn()
    print("[verify] target_date=" + target_date)

    try:
        app_id, app_secret = load_creds()
        token = get_token(app_id, app_secret)
    except Exception as e:
        print("[verify] FAIL creds/token: " + repr(e))
        return 3

    record, err = find_record(token, target_date)
    if err:
        print("[verify] FAIL search: " + err)
        return 3
    if not record:
        print("[verify] MISSING no record for " + target_date)
        return 1

    fields = record["fields"]
    name_field = fields.get("日报名", "")
    if isinstance(name_field, list):
        name_field = name_field[0].get("text", "") if name_field else ""

    expected_name = "科技日报 " + target_date
    if name_field != expected_name:
        print("[verify] MISMATCH 日报名=" + repr(name_field) + " expected=" + repr(expected_name))
        return 2

    attach = fields.get("产出", [])
    if not attach:
        print("[verify] MISMATCH no 产出 attachment")
        return 2

    expected_file = "科技日报 " + target_date + ".html"
    actual_file = attach[0].get("name", "")
    if actual_file != expected_file:
        print("[verify] MISMATCH 产出[0].name=" + repr(actual_file) + " expected=" + repr(expected_file))
        return 2

    print("[verify] OK record_id=" + record["record_id"]
          + " name=" + repr(name_field)
          + " attach=" + repr(actual_file)
          + " size=" + str(attach[0].get("size", "?")))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("[verify] CRASH: " + repr(e))
        sys.exit(3)
