#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sync_to_bitable.py
把日报 HTML 同步到飞书多维表格 "科技日报-每日更新"。

必填环境变量 (在 .env 配):
  FEISHU_BITABLE_APP_TOKEN     飞书 Bitable 应用 token (base58 字符串)
  FEISHU_BITABLE_TABLE_ID      飞书 Bitable table_id (tbls... 开头)

Bitable 字段:
  日报日期   (Text)         - 例 "2026-06-22"
  日报名     (Text)         - 例 "科技日报 2026-06-22"
  产出类型   (MultiSelect)  - 固定 ["Html"]
  产出       (Attachment)   - drive 媒体资源

规范命名 (2026-06-24 用户约定):
  不论磁盘上的 HTML 文件叫 科技日报V1.0-2026-6-24.html / daily-V1.1 / 科技日报 V1.2 ...
  Bitable 的 日报名 和 飞书云盘附件 name 一律为 "科技日报 YYYY-MM-DD[.html]"。
  避免历史命名混乱, 也避免日后升 V1.1/V1.2 又要批量改。

去重策略: 按 "日报日期" 单 key 命中则跳过 (兼容 "2026-6-22" 和 "2026-06-22" 两种格式)。
        但同日若 日报名 / 附件 name 不一致, 会 update 到规范名 (而非纯 skip)。

Usage:
  python sync_to_bitable.py <html_path> [--dry-run]

依赖: requests (agent 嵌入式 python 自带)
"""

import os
import re
import sys
import json
import yaml
import requests

APP_TOKEN = os.environ.get("FEISHU_BITABLE_APP_TOKEN")
TABLE_ID  = os.environ.get("FEISHU_BITABLE_TABLE_ID")

if not APP_TOKEN or not TABLE_ID:
    raise RuntimeError(
        "FEISHU_BITABLE_APP_TOKEN / FEISHU_BITABLE_TABLE_ID 未配置, 在 .env 填上"
    )

DEFAULT_PROD_TYPE = ["Html"]


def load_feishu_creds():
    cfg_path = os.path.expanduser(r"~\.agent\config.yaml")
    with open(cfg_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    feishu = cfg.get("platforms", {}).get("feishu", {}).get("extra", {})
    return feishu["app_id"], feishu["app_secret"]


def get_tenant_token(app_id, app_secret):
    r = requests.post(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": app_id, "app_secret": app_secret},
        timeout=15,
    )
    r.raise_for_status()
    return r.json()["tenant_access_token"]


def upload_drive_media(token, file_path, upload_file_name=None):
    """上传到飞书云空间, 拿 file_token (Bitable 附件用这个, 不是 im/v1/files 的)。

    upload_file_name: 上传时显示的 file_name; 默认用磁盘原文件名。规范命名时传 "科技日报 YYYY-MM-DD.html"。
    """
    file_name = upload_file_name or os.path.basename(file_path)
    with open(file_path, "rb") as f:
        r = requests.post(
            "https://open.feishu.cn/open-apis/drive/v1/medias/upload_all",
            headers={"Authorization": "Bearer " + token},
            data={
                "file_name": file_name,
                "parent_type": "bitable_file",
                "parent_node": APP_TOKEN,
                "size": str(os.path.getsize(file_path)),
            },
            files={"file": (file_name, f, "text/html")},
            timeout=60,
        )
    j = r.json()
    if j.get("code") != 0:
        raise RuntimeError("drive upload failed: " + str(j.get("code")) + " " + str(j.get("msg")) + " body=" + str(j))
    return j["data"]["file_token"]


def list_records(token, page_size=100):
    r = requests.get(
        "https://open.feishu.cn/open-apis/bitable/v1/apps/" + APP_TOKEN + "/tables/" + TABLE_ID + "/records",
        headers={"Authorization": "Bearer " + token},
        params={"page_size": page_size},
        timeout=15,
    )
    j = r.json()
    if j.get("code") != 0:
        raise RuntimeError("list records failed: " + str(j.get("code")) + " " + str(j.get("msg")))
    return j["data"].get("items", []), j["data"].get("total", 0)


def norm_date(s):
    """把 '2026-6-22' / '2026-06-22' 都规整为 '2026-06-22'。"""
    m = re.match(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})\s*$", str(s))
    if m:
        y, mo, d = m.groups()
        return "%04d-%02d-%02d" % (int(y), int(mo), int(d))
    return str(s).strip()


def find_existing(records, report_date):
    target = norm_date(report_date)
    for r in records:
        if norm_date(r.get("fields", {}).get("日报日期", "")) == target:
            return r["record_id"]
    return None


def create_record(token, fields):
    r = requests.post(
        "https://open.feishu.cn/open-apis/bitable/v1/apps/" + APP_TOKEN + "/tables/" + TABLE_ID + "/records",
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json; charset=utf-8",
        },
        params={"user_id_type": "open_id"},
        data=json.dumps({"fields": fields}, ensure_ascii=False),
        timeout=15,
    )
    j = r.json()
    if j.get("code") != 0:
        raise RuntimeError("create record failed: " + str(j.get("code")) + " " + str(j.get("msg")) + " body=" + str(j))
    return j["data"]["record"]["record_id"]


def update_record(token, record_id, fields):
    """Update an existing Bitable record. Used when same date exists but the
    file_name / attachment changed (e.g. daily-V1.0 -> 科技日报V1.0-2026-6-24).
    Per L2/team conventions we treat name + 产出 as the mutable fields; date is the key."""
    r = requests.put(
        "https://open.feishu.cn/open-apis/bitable/v1/apps/" + APP_TOKEN + "/tables/" + TABLE_ID + "/records/" + record_id,
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json; charset=utf-8",
        },
        params={"user_id_type": "open_id"},
        data=json.dumps({"fields": fields}, ensure_ascii=False),
        timeout=15,
    )
    j = r.json()
    if j.get("code") != 0:
        raise RuntimeError("update record failed: " + str(j.get("code")) + " " + str(j.get("msg")) + " body=" + str(j))
    return record_id


def find_existing_full(records, report_date, report_name):
    """Like find_existing, but also returns the existing name field if found."""
    target = norm_date(report_date)
    for r in records:
        f = r.get("fields", {})
        if norm_date(f.get("日报日期", "")) == target:
            return r["record_id"], f.get("日报名", "")
    return None, ""


# ---------------- 文件名解析 ----------------
DATE_PATTERN = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})")
VERSION_PATTERN = re.compile(r"(V\d+(?:\.\d+)*)")


def parse_from_dir_and_file(dir_name, file_name):
    version = None
    m = VERSION_PATTERN.search(file_name)
    if m:
        version = m.group(1)
    if version is None:
        m = VERSION_PATTERN.search(dir_name)
        if m:
            version = m.group(1)
    if version is None:
        raise ValueError("无法从 " + dir_name + "/" + file_name + " 解析版本号")

    date_str = None
    m = DATE_PATTERN.search(dir_name)
    if m:
        y, mo, d = m.groups()[:3]
        date_str = ("%04d-%02d-%02d" % (int(y), int(mo), int(d)))
    if date_str is None:
        # fallback: file_name like 科技日报V1.0-2026-6-24.html
        m = DATE_PATTERN.search(file_name)
        if m:
            y, mo, d = m.groups()[:3]
            date_str = ("%04d-%02d-%02d" % (int(y), int(mo), int(d)))

    if date_str is None:
        raise ValueError("无法从 " + dir_name + " 解析日期")

    # 强制规范命名 (用户约定 2026-06-24):  "科技日报 YYYY-MM-DD"
    # 磁盘文件名可以是 科技日报V1.0-2026-6-24.html / daily-V1.1 / 科技日报 V1.2 ... 等等,
    # 但 Bitable / 飞书 DM 一律展示规范名, 避免历史命名混乱。
    report_name = "科技日报 " + date_str
    return date_str, version, report_name


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    dry_run = "--dry-run" in flags

    if len(args) < 1:
        print("usage: sync_to_bitable.py <html_path> [--dry-run]")
        sys.exit(1)
    html_path = os.path.abspath(args[0])
    if not os.path.exists(html_path):
        print("FAIL: file not found: " + html_path)
        sys.exit(1)

    file_name = os.path.basename(html_path)
    dir_name = os.path.basename(os.path.dirname(html_path))
    file_size = os.path.getsize(html_path)

    report_date, version, report_name = parse_from_dir_and_file(dir_name, file_name)
    print("[parse] dir=" + dir_name + "  file=" + file_name)
    upload_file_name = report_name + ".html"
    print("        -> date=" + report_date + "  name=" + report_name + "  upload_as=" + upload_file_name + "  size=" + str(file_size) + "B")

    app_id, app_secret = load_feishu_creds()
    print("[creds] app_id=" + app_id[:10] + "...  table=" + TABLE_ID[:10] + "...")
    token = get_tenant_token(app_id, app_secret)
    print("[token] OK")

    records, total = list_records(token)
    print("[list] total_rows=" + str(total))
    existing_id, existing_name = find_existing_full(records, report_date, report_name)
    if existing_id:
        existing_rec = next((r for r in records if r["record_id"] == existing_id), None)
        existing_att_name = ""
        if existing_rec:
            existing_att = existing_rec.get("fields", {}).get("产出", [])
            if existing_att:
                existing_att_name = existing_att[0].get("name", "")
        if existing_name == report_name and existing_att_name == upload_file_name:
            print("[skip] 当天已有规范命名记录 record_id=" + existing_id + " (name=" + report_name + ")")
            print("       -> 不重复上传, 不重复建行")
            return
        print("[update] 当天记录存在, 规范化为新名: old_name='" + str(existing_name) + "' new_name='" + report_name + "'")
        print("         old_att='" + existing_att_name + "' new_att='" + upload_file_name + "'")
        if dry_run:
            print("[dry-run] 将 update record_id=" + existing_id)
            return
        print("[upload] " + upload_file_name + " (本地源=" + file_name + ") parent=bitable_file/" + APP_TOKEN)
        file_token = upload_drive_media(token, html_path, upload_file_name=upload_file_name)
        print("[upload] OK file_token=" + file_token)
        update_fields = {
            "日报名": report_name,
            "产出类型": DEFAULT_PROD_TYPE,
            "产出": [{"file_token": file_token, "name": upload_file_name}],
        }
        update_record(token, existing_id, update_fields)
        print("[update] OK record_id=" + existing_id + "  (name -> " + report_name + ")")
        print("\n[OK] 已 update Bitable: " + report_name + " (" + report_date + ")")
        return

    if dry_run:
        print("[dry-run] 将上传并创建: date=" + report_date + "  name=" + report_name + "  type=" + str(DEFAULT_PROD_TYPE))
        return

    print("[upload] " + upload_file_name + " (本地源=" + file_name + ") parent=bitable_file/" + APP_TOKEN)
    file_token = upload_drive_media(token, html_path, upload_file_name=upload_file_name)
    print("[upload] OK file_token=" + file_token)

    fields = {
        "日报日期": report_date,
        "日报名": report_name,
        "产出类型": DEFAULT_PROD_TYPE,
        "产出": [{"file_token": file_token, "name": upload_file_name}],
    }
    print("[create] fields=" + json.dumps(fields, ensure_ascii=False))
    new_id = create_record(token, fields)
    print("[create] OK record_id=" + new_id)
    print("\n[OK] 已同步到 Bitable: " + report_name + " (" + report_date + ")")


if __name__ == "__main__":
    main()
