# 科技日报自动化 BRIEF (投递 agent ↔ Clove 协作版)

> 给 Clove 看的简版说明,告诉 Clove: 你的 daily-digest-pipeline-skill 流程不用动, 投递 agent 端会按既定路径来抓日报发飞书。

## 角色

- **Clove (Claude Code CLI)**: 跑 daily-digest-pipeline-skill, 每天产出日报 HTML
- **投递 agent (投递 agent)**: 每天 10:10 自动抓日报, 通过飞书 DM 发给 收件人
- **收件人**: 看飞书消息即可, 不需要介入

## Clove 端 (你) 不用改

- Skill: `daily-digest-pipeline-skill/` (已就绪)
- 输出路径: `./daily-reports\YYYY-MM-DD-daily-V*.html`
- 文件命名: `daily-V<x>.<ext>` (V 号递增, 例如 V1.0 / V1.1)
- 5 步流程保持不变:
  1. `python scripts/agent.py` (抓 RSS)
  2. markitdown → `md.材料/`
  3. `python scripts/summarize_mds.py YYYY-MM-DD md.材料/ .` (LLM 总结)
  4. `python scripts/report_html_v04.py YYYY-MM-DD` (渲染 HTML)
  5. 手工 cp 到 `半自动日报更新/`, V 号递增命名

## 投递 agent 端 (约定)

- 抓取路径: `./daily-reports\YYYY-MM-DD-daily-V*`
- 文件匹配: 该子目录下 `daily-V*.html`
- 多版本时取 V 号最大那版 (V1.1 > V1.0)
- 抓取时间: 每天 10:10 (晚于 Clove 端 10:00 留 10 分钟缓冲)
- 飞书目标: 收件人 DM
- 失败兜底: 找不到文件就发"⏳ 还没出"提醒

## 硬约束 (两边共同遵守)

- Clove 只产出到 `半自动日报更新\`, **不要**写到其他路径
- 投递 agent 只读 `daily-V*.html`, **不要**读 _scripts / .bat / .log / skills / config / docs / 材料目录

## 验证

```bash
# 看 Clove 产出
ls "./daily-reports\"

# 手动触发 投递 agent 抓取
agent cron run 1e01f0179ff9
```

## 失败处理

- Clove 跑挂 → 文件不生成 → 投递 agent 10:10 发"⏳ 还没出"
- 投递 agent 投递失败 → HTML 还在磁盘, 收件人 可手动打开
- 文件命名不对 (例如 `daily-V2.0.html` 跟 投递 agent 匹配不上) → 改 投递 agent 端的 pattern

## 版本

v1.1 (2026-06-18) - 适配现有 daily-digest-pipeline-skill 流程
